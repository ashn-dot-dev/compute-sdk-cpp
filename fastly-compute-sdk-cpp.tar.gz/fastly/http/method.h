#ifndef FASTLY_HTTP_METHOD_H
#define FASTLY_HTTP_METHOD_H

#include "../sdk-sys.h"

namespace fastly::http {
using fastly::sys::http::Method;
}

#endif
