#pragma once
#include <algorithm>
#include <array>
#include <cassert>
#include <cstddef>
#include <cstdint>
#include <initializer_list>
#include <iterator>
#include <memory>
#include <new>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <utility>
#include <vector>
#if __cplusplus >= 201703L
#include <string_view>
#endif
#if __cplusplus >= 202002L
#include <ranges>
#endif

namespace rust {
inline namespace cxxbridge1 {
// #include "rust/cxx.h"

#ifndef CXXBRIDGE1_PANIC
#define CXXBRIDGE1_PANIC
template <typename Exception>
void panic [[noreturn]] (const char *msg);
#endif // CXXBRIDGE1_PANIC

struct unsafe_bitcopy_t;

namespace {
template <typename T>
class impl;
} // namespace

template <typename T>
::std::size_t size_of();
template <typename T>
::std::size_t align_of();

#ifndef CXXBRIDGE1_RUST_STRING
#define CXXBRIDGE1_RUST_STRING
class String final {
public:
  String() noexcept;
  String(const String &) noexcept;
  String(String &&) noexcept;
  ~String() noexcept;

  String(const std::string &);
  String(const char *);
  String(const char *, std::size_t);
  String(const char16_t *);
  String(const char16_t *, std::size_t);
#ifdef __cpp_char8_t
  String(const char8_t *s);
  String(const char8_t *s, std::size_t len);
#endif

  static String lossy(const std::string &) noexcept;
  static String lossy(const char *) noexcept;
  static String lossy(const char *, std::size_t) noexcept;
  static String lossy(const char16_t *) noexcept;
  static String lossy(const char16_t *, std::size_t) noexcept;

  String &operator=(const String &) & noexcept;
  String &operator=(String &&) & noexcept;

  explicit operator std::string() const;

  const char *data() const noexcept;
  std::size_t size() const noexcept;
  std::size_t length() const noexcept;
  bool empty() const noexcept;

  const char *c_str() noexcept;

  std::size_t capacity() const noexcept;
  void reserve(size_t new_cap) noexcept;

  using iterator = char *;
  iterator begin() noexcept;
  iterator end() noexcept;

  using const_iterator = const char *;
  const_iterator begin() const noexcept;
  const_iterator end() const noexcept;
  const_iterator cbegin() const noexcept;
  const_iterator cend() const noexcept;

  bool operator==(const String &) const noexcept;
  bool operator!=(const String &) const noexcept;
  bool operator<(const String &) const noexcept;
  bool operator<=(const String &) const noexcept;
  bool operator>(const String &) const noexcept;
  bool operator>=(const String &) const noexcept;

  void swap(String &) noexcept;

  String(unsafe_bitcopy_t, const String &) noexcept;

private:
  struct lossy_t;
  String(lossy_t, const char *, std::size_t) noexcept;
  String(lossy_t, const char16_t *, std::size_t) noexcept;
  friend void swap(String &lhs, String &rhs) noexcept { lhs.swap(rhs); }

  std::array<std::uintptr_t, 3> repr;
};
#endif // CXXBRIDGE1_RUST_STRING

#ifndef CXXBRIDGE1_RUST_STR
#define CXXBRIDGE1_RUST_STR
class Str final {
public:
  Str() noexcept;
  Str(const String &) noexcept;
  Str(const std::string &);
  Str(const char *);
  Str(const char *, std::size_t);

  Str &operator=(const Str &) & noexcept = default;

  explicit operator std::string() const;
#if __cplusplus >= 201703L
  explicit operator std::string_view() const;
#endif

  const char *data() const noexcept;
  std::size_t size() const noexcept;
  std::size_t length() const noexcept;
  bool empty() const noexcept;

  Str(const Str &) noexcept = default;
  ~Str() noexcept = default;

  using iterator = const char *;
  using const_iterator = const char *;
  const_iterator begin() const noexcept;
  const_iterator end() const noexcept;
  const_iterator cbegin() const noexcept;
  const_iterator cend() const noexcept;

  bool operator==(const Str &) const noexcept;
  bool operator!=(const Str &) const noexcept;
  bool operator<(const Str &) const noexcept;
  bool operator<=(const Str &) const noexcept;
  bool operator>(const Str &) const noexcept;
  bool operator>=(const Str &) const noexcept;

  void swap(Str &) noexcept;

private:
  class uninit;
  Str(uninit) noexcept;
  friend impl<Str>;

  std::array<std::uintptr_t, 2> repr;
};
#endif // CXXBRIDGE1_RUST_STR

#ifndef CXXBRIDGE1_RUST_SLICE
#define CXXBRIDGE1_RUST_SLICE
namespace detail {
template <bool>
struct copy_assignable_if {};

template <>
struct copy_assignable_if<false> {
  copy_assignable_if() noexcept = default;
  copy_assignable_if(const copy_assignable_if &) noexcept = default;
  copy_assignable_if &operator=(const copy_assignable_if &) & noexcept = delete;
  copy_assignable_if &operator=(copy_assignable_if &&) & noexcept = default;
};
} // namespace detail

template <typename T>
class Slice final
    : private detail::copy_assignable_if<std::is_const<T>::value> {
public:
  using value_type = T;

  Slice() noexcept;
  Slice(T *, std::size_t count) noexcept;

  template <typename C>
  explicit Slice(C &c) : Slice(c.data(), c.size()) {}

  Slice &operator=(const Slice<T> &) & noexcept = default;
  Slice &operator=(Slice<T> &&) & noexcept = default;

  T *data() const noexcept;
  std::size_t size() const noexcept;
  std::size_t length() const noexcept;
  bool empty() const noexcept;

  T &operator[](std::size_t n) const noexcept;
  T &at(std::size_t n) const;
  T &front() const noexcept;
  T &back() const noexcept;

  Slice(const Slice<T> &) noexcept = default;
  ~Slice() noexcept = default;

  class iterator;
  iterator begin() const noexcept;
  iterator end() const noexcept;

  void swap(Slice &) noexcept;

private:
  class uninit;
  Slice(uninit) noexcept;
  friend impl<Slice>;
  friend void sliceInit(void *, const void *, std::size_t) noexcept;
  friend void *slicePtr(const void *) noexcept;
  friend std::size_t sliceLen(const void *) noexcept;

  std::array<std::uintptr_t, 2> repr;
};

#ifdef __cpp_deduction_guides
template <typename C>
explicit Slice(C &c)
    -> Slice<std::remove_reference_t<decltype(*std::declval<C>().data())>>;
#endif // __cpp_deduction_guides

template <typename T>
class Slice<T>::iterator final {
public:
#if __cplusplus >= 202002L
  using iterator_category = std::contiguous_iterator_tag;
#else
  using iterator_category = std::random_access_iterator_tag;
#endif
  using value_type = T;
  using difference_type = std::ptrdiff_t;
  using pointer = typename std::add_pointer<T>::type;
  using reference = typename std::add_lvalue_reference<T>::type;

  reference operator*() const noexcept;
  pointer operator->() const noexcept;
  reference operator[](difference_type) const noexcept;

  iterator &operator++() noexcept;
  iterator operator++(int) noexcept;
  iterator &operator--() noexcept;
  iterator operator--(int) noexcept;

  iterator &operator+=(difference_type) noexcept;
  iterator &operator-=(difference_type) noexcept;
  iterator operator+(difference_type) const noexcept;
  friend inline iterator operator+(difference_type lhs, iterator rhs) noexcept {
    return rhs + lhs;
  }
  iterator operator-(difference_type) const noexcept;
  difference_type operator-(const iterator &) const noexcept;

  bool operator==(const iterator &) const noexcept;
  bool operator!=(const iterator &) const noexcept;
  bool operator<(const iterator &) const noexcept;
  bool operator<=(const iterator &) const noexcept;
  bool operator>(const iterator &) const noexcept;
  bool operator>=(const iterator &) const noexcept;

private:
  friend class Slice;
  void *pos;
  std::size_t stride;
};

#if __cplusplus >= 202002L
static_assert(std::ranges::contiguous_range<rust::Slice<const uint8_t>>);
static_assert(std::contiguous_iterator<rust::Slice<const uint8_t>::iterator>);
#endif

template <typename T>
Slice<T>::Slice() noexcept {
  sliceInit(this, reinterpret_cast<void *>(align_of<T>()), 0);
}

template <typename T>
Slice<T>::Slice(T *s, std::size_t count) noexcept {
  assert(s != nullptr || count == 0);
  sliceInit(this,
            s == nullptr && count == 0
                ? reinterpret_cast<void *>(align_of<T>())
                : const_cast<typename std::remove_const<T>::type *>(s),
            count);
}

template <typename T>
T *Slice<T>::data() const noexcept {
  return reinterpret_cast<T *>(slicePtr(this));
}

template <typename T>
std::size_t Slice<T>::size() const noexcept {
  return sliceLen(this);
}

template <typename T>
std::size_t Slice<T>::length() const noexcept {
  return this->size();
}

template <typename T>
bool Slice<T>::empty() const noexcept {
  return this->size() == 0;
}

template <typename T>
T &Slice<T>::operator[](std::size_t n) const noexcept {
  assert(n < this->size());
  auto ptr = static_cast<char *>(slicePtr(this)) + size_of<T>() * n;
  return *reinterpret_cast<T *>(ptr);
}

template <typename T>
T &Slice<T>::at(std::size_t n) const {
  if (n >= this->size()) {
    panic<std::out_of_range>("rust::Slice index out of range");
  }
  return (*this)[n];
}

template <typename T>
T &Slice<T>::front() const noexcept {
  assert(!this->empty());
  return (*this)[0];
}

template <typename T>
T &Slice<T>::back() const noexcept {
  assert(!this->empty());
  return (*this)[this->size() - 1];
}

template <typename T>
typename Slice<T>::iterator::reference
Slice<T>::iterator::operator*() const noexcept {
  return *static_cast<T *>(this->pos);
}

template <typename T>
typename Slice<T>::iterator::pointer
Slice<T>::iterator::operator->() const noexcept {
  return static_cast<T *>(this->pos);
}

template <typename T>
typename Slice<T>::iterator::reference Slice<T>::iterator::operator[](
    typename Slice<T>::iterator::difference_type n) const noexcept {
  auto ptr = static_cast<char *>(this->pos) + this->stride * n;
  return *reinterpret_cast<T *>(ptr);
}

template <typename T>
typename Slice<T>::iterator &Slice<T>::iterator::operator++() noexcept {
  this->pos = static_cast<char *>(this->pos) + this->stride;
  return *this;
}

template <typename T>
typename Slice<T>::iterator Slice<T>::iterator::operator++(int) noexcept {
  auto ret = iterator(*this);
  this->pos = static_cast<char *>(this->pos) + this->stride;
  return ret;
}

template <typename T>
typename Slice<T>::iterator &Slice<T>::iterator::operator--() noexcept {
  this->pos = static_cast<char *>(this->pos) - this->stride;
  return *this;
}

template <typename T>
typename Slice<T>::iterator Slice<T>::iterator::operator--(int) noexcept {
  auto ret = iterator(*this);
  this->pos = static_cast<char *>(this->pos) - this->stride;
  return ret;
}

template <typename T>
typename Slice<T>::iterator &Slice<T>::iterator::operator+=(
    typename Slice<T>::iterator::difference_type n) noexcept {
  this->pos = static_cast<char *>(this->pos) + this->stride * n;
  return *this;
}

template <typename T>
typename Slice<T>::iterator &Slice<T>::iterator::operator-=(
    typename Slice<T>::iterator::difference_type n) noexcept {
  this->pos = static_cast<char *>(this->pos) - this->stride * n;
  return *this;
}

template <typename T>
typename Slice<T>::iterator Slice<T>::iterator::operator+(
    typename Slice<T>::iterator::difference_type n) const noexcept {
  auto ret = iterator(*this);
  ret.pos = static_cast<char *>(this->pos) + this->stride * n;
  return ret;
}

template <typename T>
typename Slice<T>::iterator Slice<T>::iterator::operator-(
    typename Slice<T>::iterator::difference_type n) const noexcept {
  auto ret = iterator(*this);
  ret.pos = static_cast<char *>(this->pos) - this->stride * n;
  return ret;
}

template <typename T>
typename Slice<T>::iterator::difference_type
Slice<T>::iterator::operator-(const iterator &other) const noexcept {
  auto diff = std::distance(static_cast<char *>(other.pos),
                            static_cast<char *>(this->pos));
  return diff / static_cast<typename Slice<T>::iterator::difference_type>(
                    this->stride);
}

template <typename T>
bool Slice<T>::iterator::operator==(const iterator &other) const noexcept {
  return this->pos == other.pos;
}

template <typename T>
bool Slice<T>::iterator::operator!=(const iterator &other) const noexcept {
  return this->pos != other.pos;
}

template <typename T>
bool Slice<T>::iterator::operator<(const iterator &other) const noexcept {
  return this->pos < other.pos;
}

template <typename T>
bool Slice<T>::iterator::operator<=(const iterator &other) const noexcept {
  return this->pos <= other.pos;
}

template <typename T>
bool Slice<T>::iterator::operator>(const iterator &other) const noexcept {
  return this->pos > other.pos;
}

template <typename T>
bool Slice<T>::iterator::operator>=(const iterator &other) const noexcept {
  return this->pos >= other.pos;
}

template <typename T>
typename Slice<T>::iterator Slice<T>::begin() const noexcept {
  iterator it;
  it.pos = slicePtr(this);
  it.stride = size_of<T>();
  return it;
}

template <typename T>
typename Slice<T>::iterator Slice<T>::end() const noexcept {
  iterator it = this->begin();
  it.pos = static_cast<char *>(it.pos) + it.stride * this->size();
  return it;
}

template <typename T>
void Slice<T>::swap(Slice &rhs) noexcept {
  std::swap(*this, rhs);
}
#endif // CXXBRIDGE1_RUST_SLICE

#ifndef CXXBRIDGE1_RUST_BOX
#define CXXBRIDGE1_RUST_BOX
template <typename T>
class Box final {
public:
  using element_type = T;
  using const_pointer =
      typename std::add_pointer<typename std::add_const<T>::type>::type;
  using pointer = typename std::add_pointer<T>::type;

  Box() = delete;
  Box(Box &&) noexcept;
  ~Box() noexcept;

  explicit Box(const T &);
  explicit Box(T &&);

  Box &operator=(Box &&) & noexcept;

  const T *operator->() const noexcept;
  const T &operator*() const noexcept;
  T *operator->() noexcept;
  T &operator*() noexcept;

  template <typename... Fields>
  static Box in_place(Fields &&...);

  void swap(Box &) noexcept;

  static Box from_raw(T *) noexcept;

  T *into_raw() noexcept;

  /* Deprecated */ using value_type = element_type;

private:
  class uninit;
  class allocation;
  Box(uninit) noexcept;
  void drop() noexcept;

  friend void swap(Box &lhs, Box &rhs) noexcept { lhs.swap(rhs); }

  T *ptr;
};

template <typename T>
class Box<T>::uninit {};

template <typename T>
class Box<T>::allocation {
  static T *alloc() noexcept;
  static void dealloc(T *) noexcept;

public:
  allocation() noexcept : ptr(alloc()) {}
  ~allocation() noexcept {
    if (this->ptr) {
      dealloc(this->ptr);
    }
  }
  T *ptr;
};

template <typename T>
Box<T>::Box(Box &&other) noexcept : ptr(other.ptr) {
  other.ptr = nullptr;
}

template <typename T>
Box<T>::Box(const T &val) {
  allocation alloc;
  ::new (alloc.ptr) T(val);
  this->ptr = alloc.ptr;
  alloc.ptr = nullptr;
}

template <typename T>
Box<T>::Box(T &&val) {
  allocation alloc;
  ::new (alloc.ptr) T(std::move(val));
  this->ptr = alloc.ptr;
  alloc.ptr = nullptr;
}

template <typename T>
Box<T>::~Box() noexcept {
  if (this->ptr) {
    this->drop();
  }
}

template <typename T>
Box<T> &Box<T>::operator=(Box &&other) & noexcept {
  if (this->ptr) {
    this->drop();
  }
  this->ptr = other.ptr;
  other.ptr = nullptr;
  return *this;
}

template <typename T>
const T *Box<T>::operator->() const noexcept {
  return this->ptr;
}

template <typename T>
const T &Box<T>::operator*() const noexcept {
  return *this->ptr;
}

template <typename T>
T *Box<T>::operator->() noexcept {
  return this->ptr;
}

template <typename T>
T &Box<T>::operator*() noexcept {
  return *this->ptr;
}

template <typename T>
template <typename... Fields>
Box<T> Box<T>::in_place(Fields &&...fields) {
  allocation alloc;
  auto ptr = alloc.ptr;
  ::new (ptr) T{std::forward<Fields>(fields)...};
  alloc.ptr = nullptr;
  return from_raw(ptr);
}

template <typename T>
void Box<T>::swap(Box &rhs) noexcept {
  using std::swap;
  swap(this->ptr, rhs.ptr);
}

template <typename T>
Box<T> Box<T>::from_raw(T *raw) noexcept {
  Box box = uninit{};
  box.ptr = raw;
  return box;
}

template <typename T>
T *Box<T>::into_raw() noexcept {
  T *raw = this->ptr;
  this->ptr = nullptr;
  return raw;
}

template <typename T>
Box<T>::Box(uninit) noexcept {}
#endif // CXXBRIDGE1_RUST_BOX

#ifndef CXXBRIDGE1_RUST_BITCOPY_T
#define CXXBRIDGE1_RUST_BITCOPY_T
struct unsafe_bitcopy_t final {
  explicit unsafe_bitcopy_t() = default;
};
#endif // CXXBRIDGE1_RUST_BITCOPY_T

#ifndef CXXBRIDGE1_RUST_VEC
#define CXXBRIDGE1_RUST_VEC
template <typename T>
class Vec final {
public:
  using value_type = T;

  Vec() noexcept;
  Vec(std::initializer_list<T>);
  Vec(const Vec &);
  Vec(Vec &&) noexcept;
  ~Vec() noexcept;

  Vec &operator=(Vec &&) & noexcept;
  Vec &operator=(const Vec &) &;

  std::size_t size() const noexcept;
  bool empty() const noexcept;
  const T *data() const noexcept;
  T *data() noexcept;
  std::size_t capacity() const noexcept;

  const T &operator[](std::size_t n) const noexcept;
  const T &at(std::size_t n) const;
  const T &front() const noexcept;
  const T &back() const noexcept;

  T &operator[](std::size_t n) noexcept;
  T &at(std::size_t n);
  T &front() noexcept;
  T &back() noexcept;

  void reserve(std::size_t new_cap);
  void push_back(const T &value);
  void push_back(T &&value);
  template <typename... Args>
  void emplace_back(Args &&...args);
  void truncate(std::size_t len);
  void clear();

  using iterator = typename Slice<T>::iterator;
  iterator begin() noexcept;
  iterator end() noexcept;

  using const_iterator = typename Slice<const T>::iterator;
  const_iterator begin() const noexcept;
  const_iterator end() const noexcept;
  const_iterator cbegin() const noexcept;
  const_iterator cend() const noexcept;

  void swap(Vec &) noexcept;

  Vec(unsafe_bitcopy_t, const Vec &) noexcept;

private:
  void reserve_total(std::size_t new_cap) noexcept;
  void set_len(std::size_t len) noexcept;
  void drop() noexcept;

  friend void swap(Vec &lhs, Vec &rhs) noexcept { lhs.swap(rhs); }

  std::array<std::uintptr_t, 3> repr;
};

template <typename T>
Vec<T>::Vec(std::initializer_list<T> init) : Vec{} {
  this->reserve_total(init.size());
  std::move(init.begin(), init.end(), std::back_inserter(*this));
}

template <typename T>
Vec<T>::Vec(const Vec &other) : Vec() {
  this->reserve_total(other.size());
  std::copy(other.begin(), other.end(), std::back_inserter(*this));
}

template <typename T>
Vec<T>::Vec(Vec &&other) noexcept : repr(other.repr) {
  new (&other) Vec();
}

template <typename T>
Vec<T>::~Vec() noexcept {
  this->drop();
}

template <typename T>
Vec<T> &Vec<T>::operator=(Vec &&other) & noexcept {
  this->drop();
  this->repr = other.repr;
  new (&other) Vec();
  return *this;
}

template <typename T>
Vec<T> &Vec<T>::operator=(const Vec &other) & {
  if (this != &other) {
    this->drop();
    new (this) Vec(other);
  }
  return *this;
}

template <typename T>
bool Vec<T>::empty() const noexcept {
  return this->size() == 0;
}

template <typename T>
T *Vec<T>::data() noexcept {
  return const_cast<T *>(const_cast<const Vec<T> *>(this)->data());
}

template <typename T>
const T &Vec<T>::operator[](std::size_t n) const noexcept {
  assert(n < this->size());
  auto data = reinterpret_cast<const char *>(this->data());
  return *reinterpret_cast<const T *>(data + n * size_of<T>());
}

template <typename T>
const T &Vec<T>::at(std::size_t n) const {
  if (n >= this->size()) {
    panic<std::out_of_range>("rust::Vec index out of range");
  }
  return (*this)[n];
}

template <typename T>
const T &Vec<T>::front() const noexcept {
  assert(!this->empty());
  return (*this)[0];
}

template <typename T>
const T &Vec<T>::back() const noexcept {
  assert(!this->empty());
  return (*this)[this->size() - 1];
}

template <typename T>
T &Vec<T>::operator[](std::size_t n) noexcept {
  assert(n < this->size());
  auto data = reinterpret_cast<char *>(this->data());
  return *reinterpret_cast<T *>(data + n * size_of<T>());
}

template <typename T>
T &Vec<T>::at(std::size_t n) {
  if (n >= this->size()) {
    panic<std::out_of_range>("rust::Vec index out of range");
  }
  return (*this)[n];
}

template <typename T>
T &Vec<T>::front() noexcept {
  assert(!this->empty());
  return (*this)[0];
}

template <typename T>
T &Vec<T>::back() noexcept {
  assert(!this->empty());
  return (*this)[this->size() - 1];
}

template <typename T>
void Vec<T>::reserve(std::size_t new_cap) {
  this->reserve_total(new_cap);
}

template <typename T>
void Vec<T>::push_back(const T &value) {
  this->emplace_back(value);
}

template <typename T>
void Vec<T>::push_back(T &&value) {
  this->emplace_back(std::move(value));
}

template <typename T>
template <typename... Args>
void Vec<T>::emplace_back(Args &&...args) {
  auto size = this->size();
  this->reserve_total(size + 1);
  ::new (reinterpret_cast<T *>(reinterpret_cast<char *>(this->data()) +
                               size * size_of<T>()))
      T(std::forward<Args>(args)...);
  this->set_len(size + 1);
}

template <typename T>
void Vec<T>::clear() {
  this->truncate(0);
}

template <typename T>
typename Vec<T>::iterator Vec<T>::begin() noexcept {
  return Slice<T>(this->data(), this->size()).begin();
}

template <typename T>
typename Vec<T>::iterator Vec<T>::end() noexcept {
  return Slice<T>(this->data(), this->size()).end();
}

template <typename T>
typename Vec<T>::const_iterator Vec<T>::begin() const noexcept {
  return this->cbegin();
}

template <typename T>
typename Vec<T>::const_iterator Vec<T>::end() const noexcept {
  return this->cend();
}

template <typename T>
typename Vec<T>::const_iterator Vec<T>::cbegin() const noexcept {
  return Slice<const T>(this->data(), this->size()).begin();
}

template <typename T>
typename Vec<T>::const_iterator Vec<T>::cend() const noexcept {
  return Slice<const T>(this->data(), this->size()).end();
}

template <typename T>
void Vec<T>::swap(Vec &rhs) noexcept {
  using std::swap;
  swap(this->repr, rhs.repr);
}

template <typename T>
Vec<T>::Vec(unsafe_bitcopy_t, const Vec &bits) noexcept : repr(bits.repr) {}
#endif // CXXBRIDGE1_RUST_VEC

#ifndef CXXBRIDGE1_RUST_OPAQUE
#define CXXBRIDGE1_RUST_OPAQUE
class Opaque {
public:
  Opaque() = delete;
  Opaque(const Opaque &) = delete;
  ~Opaque() = delete;
};
#endif // CXXBRIDGE1_RUST_OPAQUE

#ifndef CXXBRIDGE1_IS_COMPLETE
#define CXXBRIDGE1_IS_COMPLETE
namespace detail {
namespace {
template <typename T, typename = std::size_t>
struct is_complete : std::false_type {};
template <typename T>
struct is_complete<T, decltype(sizeof(T))> : std::true_type {};
} // namespace
} // namespace detail
#endif // CXXBRIDGE1_IS_COMPLETE

#ifndef CXXBRIDGE1_LAYOUT
#define CXXBRIDGE1_LAYOUT
class layout {
  template <typename T>
  friend std::size_t size_of();
  template <typename T>
  friend std::size_t align_of();
  template <typename T>
  static typename std::enable_if<std::is_base_of<Opaque, T>::value,
                                 std::size_t>::type
  do_size_of() {
    return T::layout::size();
  }
  template <typename T>
  static typename std::enable_if<!std::is_base_of<Opaque, T>::value,
                                 std::size_t>::type
  do_size_of() {
    return sizeof(T);
  }
  template <typename T>
  static
      typename std::enable_if<detail::is_complete<T>::value, std::size_t>::type
      size_of() {
    return do_size_of<T>();
  }
  template <typename T>
  static typename std::enable_if<std::is_base_of<Opaque, T>::value,
                                 std::size_t>::type
  do_align_of() {
    return T::layout::align();
  }
  template <typename T>
  static typename std::enable_if<!std::is_base_of<Opaque, T>::value,
                                 std::size_t>::type
  do_align_of() {
    return alignof(T);
  }
  template <typename T>
  static
      typename std::enable_if<detail::is_complete<T>::value, std::size_t>::type
      align_of() {
    return do_align_of<T>();
  }
};

template <typename T>
std::size_t size_of() {
  return layout::size_of<T>();
}

template <typename T>
std::size_t align_of() {
  return layout::align_of<T>();
}
#endif // CXXBRIDGE1_LAYOUT
} // namespace cxxbridge1
} // namespace rust

namespace fastly {
  namespace sys {
    namespace error {
      enum class FastlyErrorCode : ::std::size_t;
      struct FastlyError;
    }
    namespace http {
      enum class Method : ::std::uint8_t;
      struct HeaderValuesIter;
      struct Request;
      struct Response;
      struct Body;
      struct StreamingBody;
      namespace request {
        struct PollResult;
        struct PendingRequest;
        struct BoxPendingRequest;
        struct AsyncStreamRes;
      }
    }
    namespace geo {
      enum class ConnSpeed : ::std::uint8_t;
      enum class ConnType : ::std::uint8_t;
      enum class Continent : ::std::uint8_t;
      enum class ProxyDescription : ::std::uint8_t;
      enum class ProxyType : ::std::uint8_t;
      struct UtcOffset;
      struct Geo;
    }
    namespace backend {
      struct Backend;
      struct BackendBuilder;
    }
    namespace device_detection {
      struct Device;
    }
    namespace config_store {
      struct ConfigStore;
    }
    namespace secret_store {
      struct Secret;
      struct SecretStore;
    }
  }
}

namespace fastly {
namespace sys {
namespace error {
#ifndef CXXBRIDGE1_ENUM_fastly$sys$error$FastlyErrorCode
#define CXXBRIDGE1_ENUM_fastly$sys$error$FastlyErrorCode
enum class FastlyErrorCode : ::std::size_t {
  Utf8Error = 0,
  InvalidHeaderName = 1,
  InvalidHeaderValue = 2,
  InvalidStatusCode = 3,
  IoError = 4,
  FastlyError = 5,
  FastlySendError = 6,
  AddrParseError = 7,
  BackendError = 8,
  BackendCreationError = 9,
  FastlyStatus = 10,
  ConfigStoreOpenError = 11,
  ConfigStoreLookupError = 12,
  SecretStoreOpenError = 13,
  SecretStoreLookupError = 14,
};
#endif // CXXBRIDGE1_ENUM_fastly$sys$error$FastlyErrorCode
} // namespace error

namespace http {
#ifndef CXXBRIDGE1_ENUM_fastly$sys$http$Method
#define CXXBRIDGE1_ENUM_fastly$sys$http$Method
enum class Method : ::std::uint8_t {
  GET = 0,
  POST = 1,
  PUT = 2,
  DELETE = 3,
  HEAD = 4,
  OPTIONS = 5,
  CONNECT = 6,
  PATCH = 7,
  TRACE = 8,
};
#endif // CXXBRIDGE1_ENUM_fastly$sys$http$Method
} // namespace http

namespace geo {
#ifndef CXXBRIDGE1_ENUM_fastly$sys$geo$ConnSpeed
#define CXXBRIDGE1_ENUM_fastly$sys$geo$ConnSpeed
// Connection speed.
//
// These connection speeds imply different latencies, as well as throughput.
//
// See [OC rates][oc] and [T-carrier][t] for background on OC- and T- connections.
//
// [oc]: https://en.wikipedia.org/wiki/Optical_Carrier_transmission_rates
// [t]: https://en.wikipedia.org/wiki/T-carrier
enum class ConnSpeed : ::std::uint8_t {
  Broadband = 0,
  Cable = 1,
  Dialup = 2,
  Mobile = 3,
  Oc12 = 4,
  Oc3 = 5,
  Satellite = 6,
  T1 = 7,
  T3 = 8,
  UltraBroadband = 9,
  Wireless = 10,
  Xdsl = 11,
  Other = 12,
};
#endif // CXXBRIDGE1_ENUM_fastly$sys$geo$ConnSpeed

#ifndef CXXBRIDGE1_ENUM_fastly$sys$geo$ConnType
#define CXXBRIDGE1_ENUM_fastly$sys$geo$ConnType
// Connection type.
//
// Defaults to `Unknown` when the connection type is not known. `Other`
// means a connection known to the database but that this version of the
// library might not yet be aware of.
enum class ConnType : ::std::uint8_t {
  Wired = 0,
  Wifi = 1,
  Mobile = 2,
  Dialup = 3,
  Satellite = 4,
  Unknown = 5,
  Other = 6,
};
#endif // CXXBRIDGE1_ENUM_fastly$sys$geo$ConnType

#ifndef CXXBRIDGE1_ENUM_fastly$sys$geo$Continent
#define CXXBRIDGE1_ENUM_fastly$sys$geo$Continent
// Continent.
enum class Continent : ::std::uint8_t {
  Africa = 0,
  Antarctica = 1,
  Asia = 2,
  Europe = 3,
  NorthAmerica = 4,
  Oceania = 5,
  SouthAmerica = 6,
  Other = 7,
};
#endif // CXXBRIDGE1_ENUM_fastly$sys$geo$Continent

#ifndef CXXBRIDGE1_ENUM_fastly$sys$geo$ProxyDescription
#define CXXBRIDGE1_ENUM_fastly$sys$geo$ProxyDescription
// Client proxy description.
//
// Defaults to `Unknown` when an IP address is not known to be a proxy or VPN.
enum class ProxyDescription : ::std::uint8_t {
  // Enables ubiquitous network access to a shared pool of configurable
  // computing resources.
  Cloud = 0,
  // A host accessing the internet via a web security and data protection
  // cloud provider.
  //
  // Example providers with this type of service are Zscaler, Scansafe,
  // and Onavo.
  CloudSecurity = 1,
  // A proxy used by overriding the client's DNS value for an endpoint
  // host to that of the proxy instead of the actual DNS value.
  Dns = 2,
  // The gateway nodes where encrypted or anonymous Tor traffic hits the
  // internet.
  TorExit = 3,
  // Receives traffic on the Tor network and passes it along; also
  // referred to as "routers".
  TorRelay = 4,
  // Virtual private network that encrypts and routes all traffic through
  // the VPN server, including programs and applications.
  Vpn = 5,
  // Connectivity that is taking place through mobile device web browser software that proxies
  // the user through a centralized location.
  //
  // Examples of such browsers are Opera mobile browsers and UCBrowser.
  WebBrowser = 6,
  // An IP address that is not known to be a proxy or VPN.
  Unknown = 7,
  // Description of a proxy or VPN that is known, but not in the above list of variants.
  //
  // This typically indicates that the geolocation database contains a proxy description that
  // did not exist when this crate was published.
  Other = 8,
};
#endif // CXXBRIDGE1_ENUM_fastly$sys$geo$ProxyDescription

#ifndef CXXBRIDGE1_ENUM_fastly$sys$geo$ProxyType
#define CXXBRIDGE1_ENUM_fastly$sys$geo$ProxyType
// Client proxy type.
//
// Defaults to `Unknown` when an IP address is not known to be a proxy or VPN.
enum class ProxyType : ::std::uint8_t {
  Anonymous = 0,
  Aol = 1,
  Blackberry = 2,
  Corporate = 3,
  Edu = 4,
  Hosting = 5,
  Public = 6,
  Transparent = 7,
  Unknown = 8,
  Other = 9,
};
#endif // CXXBRIDGE1_ENUM_fastly$sys$geo$ProxyType
} // namespace geo

namespace error {
#ifndef CXXBRIDGE1_STRUCT_fastly$sys$error$FastlyError
#define CXXBRIDGE1_STRUCT_fastly$sys$error$FastlyError
struct FastlyError final : public ::rust::Opaque {
  ::fastly::sys::error::FastlyErrorCode error_code() const noexcept;
  void error_msg(::std::string &out) const noexcept;
  ~FastlyError() = delete;

private:
  friend ::rust::layout;
  struct layout {
    static ::std::size_t size() noexcept;
    static ::std::size_t align() noexcept;
  };
};
#endif // CXXBRIDGE1_STRUCT_fastly$sys$error$FastlyError
} // namespace error

namespace backend {
#ifndef CXXBRIDGE1_STRUCT_fastly$sys$backend$Backend
#define CXXBRIDGE1_STRUCT_fastly$sys$backend$Backend
struct Backend final : public ::rust::Opaque {
  bool equals(::fastly::sys::backend::Backend const &other) const noexcept;
  ::rust::Box<::fastly::sys::backend::Backend> clone() const noexcept;
  ::rust::Str name() const noexcept;
  bool exists() const noexcept;
  bool is_dynamic() const noexcept;
  ::rust::String get_host() const noexcept;
  ::std::uint16_t get_port() const noexcept;
  ::std::uint32_t get_connect_timeout() const noexcept;
  ::std::uint32_t get_first_byte_timeout() const noexcept;
  ::std::uint32_t get_between_bytes_timeout() const noexcept;
  ::std::uint32_t get_http_keepalive_time() const noexcept;
  bool get_tcp_keepalive_enable() const noexcept;
  ::std::uint32_t get_tcp_keepalive_interval() const noexcept;
  ::std::uint32_t get_tcp_keepalive_probes() const noexcept;
  ::std::uint32_t get_tcp_keepalive_time() const noexcept;
  bool is_ssl() const noexcept;
  ~Backend() = delete;

private:
  friend ::rust::layout;
  struct layout {
    static ::std::size_t size() noexcept;
    static ::std::size_t align() noexcept;
  };
};
#endif // CXXBRIDGE1_STRUCT_fastly$sys$backend$Backend

#ifndef CXXBRIDGE1_STRUCT_fastly$sys$backend$BackendBuilder
#define CXXBRIDGE1_STRUCT_fastly$sys$backend$BackendBuilder
struct BackendBuilder final : public ::rust::Opaque {
  ~BackendBuilder() = delete;

private:
  friend ::rust::layout;
  struct layout {
    static ::std::size_t size() noexcept;
    static ::std::size_t align() noexcept;
  };
};
#endif // CXXBRIDGE1_STRUCT_fastly$sys$backend$BackendBuilder
} // namespace backend

namespace http {
#ifndef CXXBRIDGE1_STRUCT_fastly$sys$http$HeaderValuesIter
#define CXXBRIDGE1_STRUCT_fastly$sys$http$HeaderValuesIter
struct HeaderValuesIter final : public ::rust::Opaque {
  ::std::unique_ptr<::std::vector<::std::uint8_t>> next() noexcept;
  ~HeaderValuesIter() = delete;

private:
  friend ::rust::layout;
  struct layout {
    static ::std::size_t size() noexcept;
    static ::std::size_t align() noexcept;
  };
};
#endif // CXXBRIDGE1_STRUCT_fastly$sys$http$HeaderValuesIter

#ifndef CXXBRIDGE1_STRUCT_fastly$sys$http$Request
#define CXXBRIDGE1_STRUCT_fastly$sys$http$Request
struct Request final : public ::rust::Opaque {
  bool is_from_client() const noexcept;
  ::rust::Box<::fastly::sys::http::Request> clone_without_body() const noexcept;
  ::rust::Box<::fastly::sys::http::Request> clone_with_body() noexcept;
  void set_body(::rust::Box<::fastly::sys::http::Body> body) noexcept;
  bool has_body() const noexcept;
  ::rust::Box<::fastly::sys::http::Body> take_body() noexcept;
  void set_body_text_plain(::std::string const &body, ::fastly::sys::error::FastlyError *&err) noexcept;
  void set_body_text_html(::std::string const &body, ::fastly::sys::error::FastlyError *&err) noexcept;
  void set_body_octet_stream(::std::vector<::std::uint8_t> const &body) noexcept;
  bool get_content_type(::std::string &out) const noexcept;
  void set_content_type(::std::string const &mime) noexcept;
  bool get_content_length(::std::size_t &out) const noexcept;
  bool contains_header(::std::string const &name, ::fastly::sys::error::FastlyError *&err) const noexcept;
  bool get_header(::std::string const &name, ::std::string &out, ::fastly::sys::error::FastlyError *&err) const noexcept;
  void get_header_all(::std::string const &name, ::fastly::sys::http::HeaderValuesIter *&out, ::fastly::sys::error::FastlyError *&err) const noexcept;
  void set_header(::std::string const &name, ::std::string const &value, ::fastly::sys::error::FastlyError *&err) noexcept;
  void append_header(::std::string const &name, ::std::string const &value, ::fastly::sys::error::FastlyError *&err) noexcept;
  bool remove_header(::std::string const &name, ::std::string &out, ::fastly::sys::error::FastlyError *&err) noexcept;
  ::fastly::sys::http::Method get_method() const noexcept;
  void set_method(::fastly::sys::http::Method method) noexcept;
  void get_url(::std::string &out) const noexcept;
  void set_url(::std::string const &url, ::fastly::sys::error::FastlyError *&err) noexcept;
  void get_path(::std::string &out) const noexcept;
  void set_path(::std::string const &path, ::fastly::sys::error::FastlyError *&err) noexcept;
  bool get_query_string(::std::string &out) const noexcept;
  bool get_query_parameter(::std::string const &param, ::std::string &out) const noexcept;
  void set_query_string(::std::string const &qs, ::fastly::sys::error::FastlyError *&err) noexcept;
  void remove_query() noexcept;
  bool get_client_ddos_detected(bool &out) const noexcept;
  bool get_client_ip_addr(::std::string &buf) const noexcept;
  bool get_server_ip_addr(::std::string &buf) const noexcept;
  void set_pass(bool pass) noexcept;
  void set_ttl(::std::uint32_t ttl) noexcept;
  void set_stale_while_revalidate(::std::uint32_t swr) noexcept;
  void set_pci(bool pci) noexcept;
  void set_surrogate_key(::std::string const &sk, ::fastly::sys::error::FastlyError *&err) noexcept;
  void set_auto_decompress_gzip(bool gzip) noexcept;
  bool fastly_key_is_valid() const noexcept;
  void set_cache_key(::std::vector<::std::uint8_t> const &key) noexcept;
  bool is_cacheable() noexcept;
  ~Request() = delete;

private:
  friend ::rust::layout;
  struct layout {
    static ::std::size_t size() noexcept;
    static ::std::size_t align() noexcept;
  };
};
#endif // CXXBRIDGE1_STRUCT_fastly$sys$http$Request

namespace request {
#ifndef CXXBRIDGE1_STRUCT_fastly$sys$http$request$PollResult
#define CXXBRIDGE1_STRUCT_fastly$sys$http$request$PollResult
struct PollResult final : public ::rust::Opaque {
  bool is_response() const noexcept;
  bool is_pending() const noexcept;
  ~PollResult() = delete;

private:
  friend ::rust::layout;
  struct layout {
    static ::std::size_t size() noexcept;
    static ::std::size_t align() noexcept;
  };
};
#endif // CXXBRIDGE1_STRUCT_fastly$sys$http$request$PollResult

#ifndef CXXBRIDGE1_STRUCT_fastly$sys$http$request$PendingRequest
#define CXXBRIDGE1_STRUCT_fastly$sys$http$request$PendingRequest
struct PendingRequest final : public ::rust::Opaque {
  ::rust::Box<::fastly::sys::http::Request> cloned_sent_req() const noexcept;
  ~PendingRequest() = delete;

private:
  friend ::rust::layout;
  struct layout {
    static ::std::size_t size() noexcept;
    static ::std::size_t align() noexcept;
  };
};
#endif // CXXBRIDGE1_STRUCT_fastly$sys$http$request$PendingRequest

#ifndef CXXBRIDGE1_STRUCT_fastly$sys$http$request$BoxPendingRequest
#define CXXBRIDGE1_STRUCT_fastly$sys$http$request$BoxPendingRequest
struct BoxPendingRequest final : public ::rust::Opaque {
  ::rust::Box<::fastly::sys::http::request::PendingRequest> extract_req() noexcept;
  ~BoxPendingRequest() = delete;

private:
  friend ::rust::layout;
  struct layout {
    static ::std::size_t size() noexcept;
    static ::std::size_t align() noexcept;
  };
};
#endif // CXXBRIDGE1_STRUCT_fastly$sys$http$request$BoxPendingRequest

#ifndef CXXBRIDGE1_STRUCT_fastly$sys$http$request$AsyncStreamRes
#define CXXBRIDGE1_STRUCT_fastly$sys$http$request$AsyncStreamRes
struct AsyncStreamRes final : public ::rust::Opaque {
  ::rust::Box<::fastly::sys::http::StreamingBody> take_body() noexcept;
  ::rust::Box<::fastly::sys::http::request::PendingRequest> take_req() noexcept;
  ~AsyncStreamRes() = delete;

private:
  friend ::rust::layout;
  struct layout {
    static ::std::size_t size() noexcept;
    static ::std::size_t align() noexcept;
  };
};
#endif // CXXBRIDGE1_STRUCT_fastly$sys$http$request$AsyncStreamRes
} // namespace request

#ifndef CXXBRIDGE1_STRUCT_fastly$sys$http$Response
#define CXXBRIDGE1_STRUCT_fastly$sys$http$Response
struct Response final : public ::rust::Opaque {
  bool is_from_backend() const noexcept;
  ::rust::Box<::fastly::sys::http::Response> clone_without_body() const noexcept;
  ::rust::Box<::fastly::sys::http::Response> clone_with_body() noexcept;
  bool has_body() const noexcept;
  void set_body(::rust::Box<::fastly::sys::http::Body> body) noexcept;
  ::rust::Box<::fastly::sys::http::Body> take_body() noexcept;
  void append_body(::rust::Box<::fastly::sys::http::Body> other) noexcept;
  void set_body_text_plain(::std::string const &body, ::fastly::sys::error::FastlyError *&err) noexcept;
  void set_body_text_html(::std::string const &body, ::fastly::sys::error::FastlyError *&err) noexcept;
  void set_body_octet_stream(::std::vector<::std::uint8_t> const &body) noexcept;
  bool get_content_type(::std::string &out) const noexcept;
  void set_content_type(::std::string const &mime) noexcept;
  bool get_content_length(::std::size_t &out) const noexcept;
  bool contains_header(::std::string const &name, ::fastly::sys::error::FastlyError *&err) const noexcept;
  bool get_header(::std::string const &name, ::std::string &out, ::fastly::sys::error::FastlyError *&err) const noexcept;
  void get_header_all(::std::string const &name, ::fastly::sys::http::HeaderValuesIter *&out, ::fastly::sys::error::FastlyError *&err) const noexcept;
  void set_header(::std::string const &name, ::std::string const &value, ::fastly::sys::error::FastlyError *&err) noexcept;
  void append_header(::std::string const &name, ::std::string const &value, ::fastly::sys::error::FastlyError *&err) noexcept;
  bool remove_header(::std::string const &name, ::std::string &out, ::fastly::sys::error::FastlyError *&err) noexcept;
  void set_status(::std::uint16_t status) noexcept;
  bool get_backend_name(::std::string &out) const noexcept;
  ::fastly::sys::backend::Backend *get_backend() const noexcept;
  bool get_backend_addr(::std::string &out) const noexcept;
  ::fastly::sys::http::Request *take_backend_request() noexcept;
  bool get_ttl(::std::uint32_t &out) const noexcept;
  bool get_age(::std::uint32_t &out) const noexcept;
  bool get_stale_while_revalidate(::std::uint32_t &out) const noexcept;
  ~Response() = delete;

private:
  friend ::rust::layout;
  struct layout {
    static ::std::size_t size() noexcept;
    static ::std::size_t align() noexcept;
  };
};
#endif // CXXBRIDGE1_STRUCT_fastly$sys$http$Response

#ifndef CXXBRIDGE1_STRUCT_fastly$sys$http$Body
#define CXXBRIDGE1_STRUCT_fastly$sys$http$Body
struct Body final : public ::rust::Opaque {
  void append(::rust::Box<::fastly::sys::http::Body> other) noexcept;
  void append_trailer(::std::string const &name, ::std::string const &value, ::fastly::sys::error::FastlyError *&err) noexcept;
  ::std::size_t read(::rust::Slice<::std::uint8_t > buf, ::fastly::sys::error::FastlyError *&err) noexcept;
  ::std::size_t write(::rust::Slice<::std::uint8_t const> bytes, ::fastly::sys::error::FastlyError *&err) noexcept;
  ~Body() = delete;

private:
  friend ::rust::layout;
  struct layout {
    static ::std::size_t size() noexcept;
    static ::std::size_t align() noexcept;
  };
};
#endif // CXXBRIDGE1_STRUCT_fastly$sys$http$Body

#ifndef CXXBRIDGE1_STRUCT_fastly$sys$http$StreamingBody
#define CXXBRIDGE1_STRUCT_fastly$sys$http$StreamingBody
struct StreamingBody final : public ::rust::Opaque {
  void append(::rust::Box<::fastly::sys::http::Body> other) noexcept;
  void append_trailer(::std::string const &name, ::std::string const &value, ::fastly::sys::error::FastlyError *&err) noexcept;
  ::std::size_t write(::rust::Slice<::std::uint8_t const> bytes, ::fastly::sys::error::FastlyError *&err) noexcept;
  ~StreamingBody() = delete;

private:
  friend ::rust::layout;
  struct layout {
    static ::std::size_t size() noexcept;
    static ::std::size_t align() noexcept;
  };
};
#endif // CXXBRIDGE1_STRUCT_fastly$sys$http$StreamingBody
} // namespace http

namespace device_detection {
#ifndef CXXBRIDGE1_STRUCT_fastly$sys$device_detection$Device
#define CXXBRIDGE1_STRUCT_fastly$sys$device_detection$Device
struct Device final : public ::rust::Opaque {
  bool device_name(::std::string &out) const noexcept;
  bool brand(::std::string &out) const noexcept;
  bool model(::std::string &out) const noexcept;
  bool hwtype(::std::string &out) const noexcept;
  bool const *is_ereader() const noexcept;
  bool const *is_gameconsole() const noexcept;
  bool const *is_mediaplayer() const noexcept;
  bool const *is_mobile() const noexcept;
  bool const *is_smarttv() const noexcept;
  bool const *is_tablet() const noexcept;
  bool const *is_tvplayer() const noexcept;
  bool const *is_desktop() const noexcept;
  bool const *is_touchscreen() const noexcept;
  ~Device() = delete;

private:
  friend ::rust::layout;
  struct layout {
    static ::std::size_t size() noexcept;
    static ::std::size_t align() noexcept;
  };
};
#endif // CXXBRIDGE1_STRUCT_fastly$sys$device_detection$Device
} // namespace device_detection

namespace config_store {
#ifndef CXXBRIDGE1_STRUCT_fastly$sys$config_store$ConfigStore
#define CXXBRIDGE1_STRUCT_fastly$sys$config_store$ConfigStore
struct ConfigStore final : public ::rust::Opaque {
  bool get(::std::string const &key, ::std::string &out, ::fastly::sys::error::FastlyError *&err) const noexcept;
  bool contains(::std::string const &key, ::fastly::sys::error::FastlyError *&err) const noexcept;
  ~ConfigStore() = delete;

private:
  friend ::rust::layout;
  struct layout {
    static ::std::size_t size() noexcept;
    static ::std::size_t align() noexcept;
  };
};
#endif // CXXBRIDGE1_STRUCT_fastly$sys$config_store$ConfigStore
} // namespace config_store

namespace secret_store {
#ifndef CXXBRIDGE1_STRUCT_fastly$sys$secret_store$Secret
#define CXXBRIDGE1_STRUCT_fastly$sys$secret_store$Secret
struct Secret final : public ::rust::Opaque {
  void plaintext(::std::string &out) const noexcept;
  ~Secret() = delete;

private:
  friend ::rust::layout;
  struct layout {
    static ::std::size_t size() noexcept;
    static ::std::size_t align() noexcept;
  };
};
#endif // CXXBRIDGE1_STRUCT_fastly$sys$secret_store$Secret

#ifndef CXXBRIDGE1_STRUCT_fastly$sys$secret_store$SecretStore
#define CXXBRIDGE1_STRUCT_fastly$sys$secret_store$SecretStore
struct SecretStore final : public ::rust::Opaque {
  void get(::std::string const &key, ::fastly::sys::secret_store::Secret *&out, ::fastly::sys::error::FastlyError *&err) const noexcept;
  bool contains(::std::string const &key, ::fastly::sys::error::FastlyError *&err) const noexcept;
  ~SecretStore() = delete;

private:
  friend ::rust::layout;
  struct layout {
    static ::std::size_t size() noexcept;
    static ::std::size_t align() noexcept;
  };
};
#endif // CXXBRIDGE1_STRUCT_fastly$sys$secret_store$SecretStore
} // namespace secret_store

namespace geo {
#ifndef CXXBRIDGE1_STRUCT_fastly$sys$geo$UtcOffset
#define CXXBRIDGE1_STRUCT_fastly$sys$geo$UtcOffset
struct UtcOffset final : public ::rust::Opaque {
  ::std::int8_t whole_hours() const noexcept;
  ::std::int16_t whole_minutes() const noexcept;
  ::std::int8_t minutes_past_hour() const noexcept;
  ::std::int32_t whole_seconds() const noexcept;
  ::std::int8_t seconds_past_minute() const noexcept;
  bool is_utc() const noexcept;
  bool is_positive() const noexcept;
  bool is_negative() const noexcept;
  ~UtcOffset() = delete;

private:
  friend ::rust::layout;
  struct layout {
    static ::std::size_t size() noexcept;
    static ::std::size_t align() noexcept;
  };
};
#endif // CXXBRIDGE1_STRUCT_fastly$sys$geo$UtcOffset

#ifndef CXXBRIDGE1_STRUCT_fastly$sys$geo$Geo
#define CXXBRIDGE1_STRUCT_fastly$sys$geo$Geo
struct Geo final : public ::rust::Opaque {
  void as_name(::std::string &out) const noexcept;
  ::std::uint32_t as_number() const noexcept;
  ::std::uint16_t area_code() const noexcept;
  void city(::std::string &out) const noexcept;
  ::fastly::sys::geo::ConnSpeed conn_speed() const noexcept;
  ::fastly::sys::geo::ConnType conn_type() const noexcept;
  ::fastly::sys::geo::Continent continent() const noexcept;
  void country_code(::std::string &out) const noexcept;
  void country_code3(::std::string &out) const noexcept;
  void country_name(::std::string &out) const noexcept;
  double latitude() const noexcept;
  double longitude() const noexcept;
  ::std::int64_t metro_code() const noexcept;
  void postal_code(::std::string &out) const noexcept;
  ::fastly::sys::geo::ProxyDescription proxy_description() const noexcept;
  ::fastly::sys::geo::ProxyType proxy_type() const noexcept;
  bool region(::std::string &out) const noexcept;
  ::fastly::sys::geo::UtcOffset *utc_offset() const noexcept;
  ~Geo() = delete;

private:
  friend ::rust::layout;
  struct layout {
    static ::std::size_t size() noexcept;
    static ::std::size_t align() noexcept;
  };
};
#endif // CXXBRIDGE1_STRUCT_fastly$sys$geo$Geo
} // namespace geo

namespace backend {
void m_static_backend_backend_from_name(::std::string const &name, ::fastly::sys::backend::Backend *&out, ::fastly::sys::error::FastlyError *&err) noexcept;

::rust::Box<::fastly::sys::backend::BackendBuilder> m_static_backend_backend_builder(::std::string const &name, ::std::string const &target) noexcept;

::rust::String m_backend_backend_into_string(::rust::Box<::fastly::sys::backend::Backend> backend) noexcept;

::rust::Box<::fastly::sys::backend::BackendBuilder> m_static_backend_backend_builder_new(::std::string const &name, ::std::string const &target) noexcept;

::rust::Box<::fastly::sys::backend::BackendBuilder> m_backend_backend_builder_override_host(::rust::Box<::fastly::sys::backend::BackendBuilder> builder, ::std::string const &name) noexcept;

::rust::Box<::fastly::sys::backend::BackendBuilder> m_backend_backend_builder_connect_timeout(::rust::Box<::fastly::sys::backend::BackendBuilder> builder, ::std::uint32_t timeout) noexcept;

::rust::Box<::fastly::sys::backend::BackendBuilder> m_backend_backend_builder_first_byte_timeout(::rust::Box<::fastly::sys::backend::BackendBuilder> builder, ::std::uint32_t timeout) noexcept;

::rust::Box<::fastly::sys::backend::BackendBuilder> m_backend_backend_builder_between_bytes_timeout(::rust::Box<::fastly::sys::backend::BackendBuilder> builder, ::std::uint32_t timeout) noexcept;

::rust::Box<::fastly::sys::backend::BackendBuilder> m_backend_backend_builder_enable_ssl(::rust::Box<::fastly::sys::backend::BackendBuilder> builder) noexcept;

::rust::Box<::fastly::sys::backend::BackendBuilder> m_backend_backend_builder_disable_ssl(::rust::Box<::fastly::sys::backend::BackendBuilder> builder) noexcept;

::rust::Box<::fastly::sys::backend::BackendBuilder> m_backend_backend_builder_check_certificate(::rust::Box<::fastly::sys::backend::BackendBuilder> builder, ::std::string const &cert) noexcept;

::rust::Box<::fastly::sys::backend::BackendBuilder> m_backend_backend_builder_ca_certificate(::rust::Box<::fastly::sys::backend::BackendBuilder> builder, ::std::string const &cert) noexcept;

::rust::Box<::fastly::sys::backend::BackendBuilder> m_backend_backend_builder_tls_ciphers(::rust::Box<::fastly::sys::backend::BackendBuilder> builder, ::std::string const &ciphers) noexcept;

::rust::Box<::fastly::sys::backend::BackendBuilder> m_backend_backend_builder_sni_hostname(::rust::Box<::fastly::sys::backend::BackendBuilder> builder, ::std::string const &host) noexcept;

::rust::Box<::fastly::sys::backend::BackendBuilder> m_backend_backend_builder_enable_pooling(::rust::Box<::fastly::sys::backend::BackendBuilder> builder, bool value) noexcept;

::rust::Box<::fastly::sys::backend::BackendBuilder> m_backend_backend_builder_http_keepalive_time(::rust::Box<::fastly::sys::backend::BackendBuilder> builder, ::std::uint32_t timeout) noexcept;

::rust::Box<::fastly::sys::backend::BackendBuilder> m_backend_backend_builder_tcp_keepalive_enable(::rust::Box<::fastly::sys::backend::BackendBuilder> builder, bool value) noexcept;

::rust::Box<::fastly::sys::backend::BackendBuilder> m_backend_backend_builder_tcp_keepalive_interval_secs(::rust::Box<::fastly::sys::backend::BackendBuilder> builder, ::std::uint32_t value) noexcept;

::rust::Box<::fastly::sys::backend::BackendBuilder> m_backend_backend_builder_tcp_keepalive_probes(::rust::Box<::fastly::sys::backend::BackendBuilder> builder, ::std::uint32_t value) noexcept;

::rust::Box<::fastly::sys::backend::BackendBuilder> m_backend_backend_builder_tcp_keepalive_time_secs(::rust::Box<::fastly::sys::backend::BackendBuilder> builder, ::std::uint32_t value) noexcept;

void m_backend_backend_builder_finish(::rust::Box<::fastly::sys::backend::BackendBuilder> builder, ::fastly::sys::backend::Backend *&out, ::fastly::sys::error::FastlyError *&err) noexcept;
} // namespace backend

namespace http {
::rust::Box<::fastly::sys::http::Request> m_static_http_request_get(::std::string const &url) noexcept;

::rust::Box<::fastly::sys::http::Request> m_static_http_request_head(::std::string const &url) noexcept;

::rust::Box<::fastly::sys::http::Request> m_static_http_request_post(::std::string const &url) noexcept;

::rust::Box<::fastly::sys::http::Request> m_static_http_request_put(::std::string const &url) noexcept;

::rust::Box<::fastly::sys::http::Request> m_static_http_request_delete(::std::string const &url) noexcept;

::rust::Box<::fastly::sys::http::Request> m_static_http_request_connect(::std::string const &url) noexcept;

::rust::Box<::fastly::sys::http::Request> m_static_http_request_options(::std::string const &url) noexcept;

::rust::Box<::fastly::sys::http::Request> m_static_http_request_trace(::std::string const &url) noexcept;

::rust::Box<::fastly::sys::http::Request> m_static_http_request_patch(::std::string const &url) noexcept;

::rust::Box<::fastly::sys::http::Request> m_static_http_request_new(::fastly::sys::http::Method method, ::std::string const &url) noexcept;

::rust::Box<::fastly::sys::http::Request> m_static_http_request_from_client() noexcept;

void m_http_request_send(::rust::Box<::fastly::sys::http::Request> request, ::fastly::sys::backend::Backend const &backend, ::fastly::sys::http::Response *&out, ::fastly::sys::error::FastlyError *&err) noexcept;

void m_http_request_send_async(::rust::Box<::fastly::sys::http::Request> request, ::fastly::sys::backend::Backend const &backend, ::fastly::sys::http::request::PendingRequest *&out, ::fastly::sys::error::FastlyError *&err) noexcept;

void m_http_request_send_async_streaming(::rust::Box<::fastly::sys::http::Request> request, ::fastly::sys::backend::Backend const &backend, ::fastly::sys::http::request::AsyncStreamRes *&out, ::fastly::sys::error::FastlyError *&err) noexcept;

::rust::Box<::fastly::sys::http::Body> m_http_request_into_body(::rust::Box<::fastly::sys::http::Request> request) noexcept;

namespace request {
::rust::Box<::fastly::sys::http::request::PendingRequest> m_http_request_poll_result_into_pending(::rust::Box<::fastly::sys::http::request::PollResult> result) noexcept;

::rust::Box<::fastly::sys::http::Response> m_http_request_poll_result_into_response(::rust::Box<::fastly::sys::http::request::PollResult> result) noexcept;

::rust::Box<::fastly::sys::error::FastlyError> m_http_request_poll_result_into_error(::rust::Box<::fastly::sys::http::request::PollResult> result) noexcept;

::rust::Box<::fastly::sys::http::request::PollResult> m_http_request_pending_request_poll(::rust::Box<::fastly::sys::http::request::PendingRequest> req) noexcept;

void m_http_request_pending_request_wait(::rust::Box<::fastly::sys::http::request::PendingRequest> req, ::fastly::sys::http::Response *&out, ::fastly::sys::error::FastlyError *&err) noexcept;

void f_http_push_box_pending_request_into_vec(::rust::Vec<::fastly::sys::http::request::BoxPendingRequest> &vec, ::rust::Box<::fastly::sys::http::request::PendingRequest> bx) noexcept;

void f_http_request_select(::rust::Vec<::fastly::sys::http::request::BoxPendingRequest> reqs, ::fastly::sys::http::Response *&out, ::rust::Vec<::fastly::sys::http::request::BoxPendingRequest> &others, ::fastly::sys::error::FastlyError *&err) noexcept;
} // namespace request

bool f_http_status_code_canonical_reason(::std::uint16_t code, ::std::string &string, ::fastly::sys::error::FastlyError *&err) noexcept;

::rust::Box<::fastly::sys::http::Response> m_static_http_response_new() noexcept;

::rust::Box<::fastly::sys::http::Response> m_static_http_response_from_body(::rust::Box<::fastly::sys::http::Body> body) noexcept;

::rust::Box<::fastly::sys::http::Response> m_static_http_response_from_status(::std::uint16_t status) noexcept;

::rust::Box<::fastly::sys::http::Response> m_static_http_response_see_other(::std::string const &destination) noexcept;

::rust::Box<::fastly::sys::http::Response> m_static_http_response_redirect(::std::string const &destination) noexcept;

::rust::Box<::fastly::sys::http::Response> m_static_http_response_temporary_redirect(::std::string const &destination) noexcept;

::rust::Box<::fastly::sys::http::Body> m_http_response_into_body(::rust::Box<::fastly::sys::http::Response> response) noexcept;

void m_http_response_send_to_client(::rust::Box<::fastly::sys::http::Response> response) noexcept;

::rust::Box<::fastly::sys::http::StreamingBody> m_http_response_stream_to_client(::rust::Box<::fastly::sys::http::Response> response) noexcept;

::rust::Box<::fastly::sys::http::Body> m_static_http_body_new() noexcept;

void m_http_streaming_body_finish(::rust::Box<::fastly::sys::http::StreamingBody> body, ::fastly::sys::error::FastlyError *&err) noexcept;

namespace purge {
void f_http_purge_purge_surrogate_key(::std::string const &surrogate_key, ::fastly::sys::error::FastlyError *&err) noexcept;

void f_http_purge_soft_purge_surrogate_key(::std::string const &surrogate_key, ::fastly::sys::error::FastlyError *&err) noexcept;
} // namespace purge
} // namespace http

namespace device_detection {
void f_device_detection_lookup(::std::string const &user_agent, ::fastly::sys::device_detection::Device *&out, ::fastly::sys::error::FastlyError *&err) noexcept;

::rust::Box<::fastly::sys::device_detection::Device> f_device_detection_noop(::rust::Box<::fastly::sys::device_detection::Device> dev) noexcept;
} // namespace device_detection

namespace config_store {
void m_static_config_store_config_store_open(::std::string const &name, ::fastly::sys::config_store::ConfigStore *&out, ::fastly::sys::error::FastlyError *&err) noexcept;
} // namespace config_store

namespace secret_store {
void m_static_secret_store_secret_from_bytes(::std::vector<::std::uint8_t> const &bytes, ::fastly::sys::secret_store::Secret *&out, ::fastly::sys::error::FastlyError *&err) noexcept;

void m_static_secret_store_secret_store_open(::std::string const &name, ::fastly::sys::secret_store::SecretStore *&out, ::fastly::sys::error::FastlyError *&err) noexcept;
} // namespace secret_store

namespace geo {
void f_geo_geo_lookup(::std::string const &ip, ::fastly::sys::geo::Geo *&out, ::fastly::sys::error::FastlyError *&err) noexcept;
} // namespace geo
} // namespace sys
} // namespace fastly
