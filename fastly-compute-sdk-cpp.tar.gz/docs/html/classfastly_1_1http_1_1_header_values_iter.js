var classfastly_1_1http_1_1_header_values_iter =
[
    [ "HeaderValuesIter", "classfastly_1_1http_1_1_header_values_iter.html#aab089675950da31d9c47e4b6738a2390", null ],
    [ "next", "classfastly_1_1http_1_1_header_values_iter.html#a355a3febe3b1830bc57e6d8dc50e3f96", null ]
];