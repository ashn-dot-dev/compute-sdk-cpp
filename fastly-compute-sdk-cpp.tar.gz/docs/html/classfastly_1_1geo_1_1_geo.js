var classfastly_1_1geo_1_1_geo =
[
    [ "area_code", "classfastly_1_1geo_1_1_geo.html#aaf86c9fae16ec8691d0a9f9acdcd1e8a", null ],
    [ "as_name", "classfastly_1_1geo_1_1_geo.html#a04dfe39bd713010c037c76a7975342ee", null ],
    [ "as_number", "classfastly_1_1geo_1_1_geo.html#a292cf302baf178b30999a5168805fe29", null ],
    [ "city", "classfastly_1_1geo_1_1_geo.html#a72362a045c21ad97c170b27e5781d404", null ],
    [ "conn_speed", "classfastly_1_1geo_1_1_geo.html#a1cbb5259572e3a983cefc072447223e2", null ],
    [ "conn_type", "classfastly_1_1geo_1_1_geo.html#a6f4bfd71bb6d3f070cc6b0cdb4d26327", null ],
    [ "continent", "classfastly_1_1geo_1_1_geo.html#a9d8652185e44ea5d70b25f75232fb6ca", null ],
    [ "country_code", "classfastly_1_1geo_1_1_geo.html#a899b35bf168316bad7523cf74a787467", null ],
    [ "country_code3", "classfastly_1_1geo_1_1_geo.html#a1d3e7c1785b2a9297fcc82a015c28b0a", null ],
    [ "country_name", "classfastly_1_1geo_1_1_geo.html#a648692a8d651f38f4808137de1e19c57", null ],
    [ "latitude", "classfastly_1_1geo_1_1_geo.html#a4067bbfa01f3d4533c58fd5bfcfb8bfa", null ],
    [ "longitude", "classfastly_1_1geo_1_1_geo.html#ab8ae39e8f2e59ef10eddfb457e4cf08e", null ],
    [ "metro_code", "classfastly_1_1geo_1_1_geo.html#ab4c3356070f88a6ebc58b05cfd620684", null ],
    [ "postal_code", "classfastly_1_1geo_1_1_geo.html#ae8ca6c56812960139abeef973f4a0f9f", null ],
    [ "proxy_description", "classfastly_1_1geo_1_1_geo.html#af0d9a0e0f5bf28cb5b534aa31b951501", null ],
    [ "proxy_type", "classfastly_1_1geo_1_1_geo.html#abe53920cdfa15bcca98ec75ac3afbd80", null ],
    [ "region", "classfastly_1_1geo_1_1_geo.html#a3fd24ef5be28c810e3221ec97fab89ec", null ],
    [ "utc_offset", "classfastly_1_1geo_1_1_geo.html#a50a5f8a41434cebbf6a356acf4788740", null ],
    [ "geo_lookup", "classfastly_1_1geo_1_1_geo.html#a308def92372cab29b28119f0f1cd2480", null ]
];