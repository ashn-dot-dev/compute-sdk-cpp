var geo_8h =
[
    [ "fastly::geo::UtcOffset", "classfastly_1_1geo_1_1_utc_offset.html", "classfastly_1_1geo_1_1_utc_offset" ],
    [ "fastly::geo::Geo", "classfastly_1_1geo_1_1_geo.html", "classfastly_1_1geo_1_1_geo" ],
    [ "fastly::geo::geo_lookup", "namespacefastly_1_1geo.html#adf483f56c28f5b6beb45e27eae7273cf", null ]
];