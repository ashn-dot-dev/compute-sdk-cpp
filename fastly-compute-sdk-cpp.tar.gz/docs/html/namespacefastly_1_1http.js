var namespacefastly_1_1http =
[
    [ "purge", "namespacefastly_1_1http_1_1purge.html", [
      [ "purge_surrogate_key", "namespacefastly_1_1http_1_1purge.html#a778040cf14e4e1a1aaaf07c07552667a", null ],
      [ "soft_purge_surrogate_key", "namespacefastly_1_1http_1_1purge.html#adc34607891e7bcd21ad67c33ea09f158", null ]
    ] ],
    [ "request", "namespacefastly_1_1http_1_1request.html", "namespacefastly_1_1http_1_1request" ],
    [ "Body", "classfastly_1_1http_1_1_body.html", "classfastly_1_1http_1_1_body" ],
    [ "HeaderValuesIter", "classfastly_1_1http_1_1_header_values_iter.html", "classfastly_1_1http_1_1_header_values_iter" ],
    [ "Request", "classfastly_1_1http_1_1_request.html", "classfastly_1_1http_1_1_request" ],
    [ "Response", "classfastly_1_1http_1_1_response.html", "classfastly_1_1http_1_1_response" ],
    [ "StatusCode", "classfastly_1_1http_1_1_status_code.html", "classfastly_1_1http_1_1_status_code" ],
    [ "StreamingBody", "classfastly_1_1http_1_1_streaming_body.html", "classfastly_1_1http_1_1_streaming_body" ]
];