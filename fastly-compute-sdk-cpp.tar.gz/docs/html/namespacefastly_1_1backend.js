var namespacefastly_1_1backend =
[
    [ "Backend", "classfastly_1_1backend_1_1_backend.html", "classfastly_1_1backend_1_1_backend" ],
    [ "BackendBuilder", "classfastly_1_1backend_1_1_backend_builder.html", "classfastly_1_1backend_1_1_backend_builder" ]
];