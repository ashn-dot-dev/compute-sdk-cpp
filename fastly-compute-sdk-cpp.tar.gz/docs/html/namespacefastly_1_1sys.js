var namespacefastly_1_1sys =
[
    [ "backend", "namespacefastly_1_1sys_1_1backend.html", "namespacefastly_1_1sys_1_1backend" ],
    [ "config_store", "namespacefastly_1_1sys_1_1config__store.html", [
      [ "m_static_config_store_config_store_open", "namespacefastly_1_1sys_1_1config__store.html#a24865d9c90f52b9d44d09b63c7ba5f67", null ]
    ] ],
    [ "device_detection", "namespacefastly_1_1sys_1_1device__detection.html", [
      [ "f_device_detection_lookup", "namespacefastly_1_1sys_1_1device__detection.html#a019fc7a470cfc84992df818b5051fa8e", null ],
      [ "f_device_detection_noop", "namespacefastly_1_1sys_1_1device__detection.html#ad4a2d0421bdb0c0363c14952d2d3b44c", null ]
    ] ],
    [ "geo", "namespacefastly_1_1sys_1_1geo.html", [
      [ "f_geo_geo_lookup", "namespacefastly_1_1sys_1_1geo.html#a455224d9a22c0c582a496ccd315ca901", null ]
    ] ],
    [ "http", "namespacefastly_1_1sys_1_1http.html", "namespacefastly_1_1sys_1_1http" ],
    [ "secret_store", "namespacefastly_1_1sys_1_1secret__store.html", [
      [ "m_static_secret_store_secret_from_bytes", "namespacefastly_1_1sys_1_1secret__store.html#af49d57ec0e3a6d49f0b5813c53028267", null ],
      [ "m_static_secret_store_secret_store_open", "namespacefastly_1_1sys_1_1secret__store.html#a46ce696d694ca8d7a56c0b0f44a0c887", null ]
    ] ]
];