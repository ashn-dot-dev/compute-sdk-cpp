var hierarchy =
[
    [ "fastly::backend::Backend", "classfastly_1_1backend_1_1_backend.html", null ],
    [ "fastly::backend::BackendBuilder", "classfastly_1_1backend_1_1_backend_builder.html", null ],
    [ "fastly::config_store::ConfigStore", "classfastly_1_1config__store_1_1_config_store.html", null ],
    [ "fastly::ConfigStore", "classfastly_1_1_config_store.html", null ],
    [ "fastly::device_detection::Device", "classfastly_1_1device__detection_1_1_device.html", null ],
    [ "fastly::error::FastlyError", "classfastly_1_1error_1_1_fastly_error.html", null ],
    [ "fastly::FastlyError", "classfastly_1_1_fastly_error.html", null ],
    [ "fastly::geo::Geo", "classfastly_1_1geo_1_1_geo.html", null ],
    [ "fastly::http::HeaderValuesIter", "classfastly_1_1http_1_1_header_values_iter.html", null ],
    [ "std::iostream", null, [
      [ "fastly::http::Body", "classfastly_1_1http_1_1_body.html", null ]
    ] ],
    [ "std::ostream", null, [
      [ "fastly::http::StreamingBody", "classfastly_1_1http_1_1_streaming_body.html", null ]
    ] ],
    [ "fastly::http::request::PendingRequest", "classfastly_1_1http_1_1request_1_1_pending_request.html", null ],
    [ "fastly::http::Request", "classfastly_1_1http_1_1_request.html", null ],
    [ "fastly::Request", "classfastly_1_1_request.html", null ],
    [ "fastly::http::Response", "classfastly_1_1http_1_1_response.html", null ],
    [ "fastly::Response", "classfastly_1_1_response.html", null ],
    [ "fastly::secret_store::Secret", "classfastly_1_1secret__store_1_1_secret.html", null ],
    [ "fastly::secret_store::SecretStore", "classfastly_1_1secret__store_1_1_secret_store.html", null ],
    [ "fastly::SecretStore", "classfastly_1_1_secret_store.html", null ],
    [ "fastly::http::StatusCode", "classfastly_1_1http_1_1_status_code.html", null ],
    [ "std::streambuf", null, [
      [ "fastly::http::Body", "classfastly_1_1http_1_1_body.html", null ],
      [ "fastly::http::StreamingBody", "classfastly_1_1http_1_1_streaming_body.html", null ]
    ] ],
    [ "fastly::geo::UtcOffset", "classfastly_1_1geo_1_1_utc_offset.html", null ]
];