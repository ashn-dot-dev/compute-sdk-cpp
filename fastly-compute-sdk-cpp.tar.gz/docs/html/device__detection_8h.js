var device__detection_8h =
[
    [ "fastly::device_detection::Device", "classfastly_1_1device__detection_1_1_device.html", "classfastly_1_1device__detection_1_1_device" ],
    [ "fastly::device_detection::lookup", "namespacefastly_1_1device__detection.html#a963348758b3806eb80f24a329fc64479", null ]
];