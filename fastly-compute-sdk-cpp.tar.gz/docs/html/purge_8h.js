var purge_8h =
[
    [ "fastly::http::purge::purge_surrogate_key", "namespacefastly_1_1http_1_1purge.html#a778040cf14e4e1a1aaaf07c07552667a", null ],
    [ "fastly::http::purge::soft_purge_surrogate_key", "namespacefastly_1_1http_1_1purge.html#adc34607891e7bcd21ad67c33ea09f158", null ]
];