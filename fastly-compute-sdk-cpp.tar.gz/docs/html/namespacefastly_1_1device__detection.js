var namespacefastly_1_1device__detection =
[
    [ "Device", "classfastly_1_1device__detection_1_1_device.html", "classfastly_1_1device__detection_1_1_device" ],
    [ "lookup", "namespacefastly_1_1device__detection.html#a963348758b3806eb80f24a329fc64479", null ]
];