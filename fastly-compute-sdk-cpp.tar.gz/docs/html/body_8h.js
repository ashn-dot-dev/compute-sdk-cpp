var body_8h =
[
    [ "fastly::http::Body", "classfastly_1_1http_1_1_body.html", "classfastly_1_1http_1_1_body" ],
    [ "fastly::http::StreamingBody", "classfastly_1_1http_1_1_streaming_body.html", "classfastly_1_1http_1_1_streaming_body" ],
    [ "fastly::Body", "classfastly_1_1_body.html", "classfastly_1_1_body" ],
    [ "fastly::http::request::select", "namespacefastly_1_1http_1_1request.html#a51ca1c5739c98242822e5303dd0907c0", null ]
];