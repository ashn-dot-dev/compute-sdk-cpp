var classfastly_1_1device__detection_1_1_device =
[
    [ "brand", "classfastly_1_1device__detection_1_1_device.html#adba06cfc700fc5b7e385636dfcf1cb04", null ],
    [ "device_name", "classfastly_1_1device__detection_1_1_device.html#adb8837d1b415101ba0fe213597418808", null ],
    [ "hwtype", "classfastly_1_1device__detection_1_1_device.html#a3c6054bed6385cc51a4a5810116eda82", null ],
    [ "is_desktop", "classfastly_1_1device__detection_1_1_device.html#a6837f429749e0db3d2d7f9d44f532c78", null ],
    [ "is_ereader", "classfastly_1_1device__detection_1_1_device.html#a8d5332c57a5bee0df231e2ed9e81a9cb", null ],
    [ "is_gameconsole", "classfastly_1_1device__detection_1_1_device.html#a0ab53d341e6e690d6f3835041644dec1", null ],
    [ "is_mediaplayer", "classfastly_1_1device__detection_1_1_device.html#a65e8a8c2c9e3615d2f1937cc280e375a", null ],
    [ "is_mobile", "classfastly_1_1device__detection_1_1_device.html#a4f12ea4b0e8f490fff09213ea849e710", null ],
    [ "is_smarttv", "classfastly_1_1device__detection_1_1_device.html#a9c249945482734a985aea39d3f778720", null ],
    [ "is_tablet", "classfastly_1_1device__detection_1_1_device.html#aeacb0fb06f4c9fb1d6189caef342db97", null ],
    [ "is_touchscreen", "classfastly_1_1device__detection_1_1_device.html#ae4c21474714b7b611f7de65c91085edd", null ],
    [ "is_tvplayer", "classfastly_1_1device__detection_1_1_device.html#a1fdf614103097c962c701ccea0df1490", null ],
    [ "model", "classfastly_1_1device__detection_1_1_device.html#a35dbfe715296cc1f9e3f589b1e61e3a4", null ],
    [ "lookup", "classfastly_1_1device__detection_1_1_device.html#a17882354a698c180ed8dc3e5917868cb", null ]
];