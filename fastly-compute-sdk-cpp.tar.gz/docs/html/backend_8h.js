var backend_8h =
[
    [ "fastly::backend::Backend", "classfastly_1_1backend_1_1_backend.html", "classfastly_1_1backend_1_1_backend" ],
    [ "fastly::backend::BackendBuilder", "classfastly_1_1backend_1_1_backend_builder.html", "classfastly_1_1backend_1_1_backend_builder" ]
];