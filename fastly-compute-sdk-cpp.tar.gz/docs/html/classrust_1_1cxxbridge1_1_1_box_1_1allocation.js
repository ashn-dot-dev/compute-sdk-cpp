var classrust_1_1cxxbridge1_1_1_box_1_1allocation =
[
    [ "allocation", "classrust_1_1cxxbridge1_1_1_box_1_1allocation.html#a830aee691a19415495152f2496bbd0b1", null ],
    [ "~allocation", "classrust_1_1cxxbridge1_1_1_box_1_1allocation.html#a03c2e792730deed42c34f15ecae6c1b2", null ],
    [ "ptr", "classrust_1_1cxxbridge1_1_1_box_1_1allocation.html#a08558e395069e27daa3e36bad4ebf567", null ]
];