var classfastly_1_1backend_1_1_backend_builder =
[
    [ "BackendBuilder", "classfastly_1_1backend_1_1_backend_builder.html#a6a50e4e049d0ffc5b5dbf10ec80b5e95", null ],
    [ "between_bytes_timeout", "classfastly_1_1backend_1_1_backend_builder.html#aaa18022ce1fcf5ffa5f1b947e5bb8a11", null ],
    [ "ca_certificate", "classfastly_1_1backend_1_1_backend_builder.html#abd87dcdab58128c5194def462bb74948", null ],
    [ "check_certificate", "classfastly_1_1backend_1_1_backend_builder.html#a12efdbd1ec5d54394e0db3d1a2751ac3", null ],
    [ "connect_timeout", "classfastly_1_1backend_1_1_backend_builder.html#a2fdd2316c4fc1c0490fd9f9625dfb035", null ],
    [ "disable_ssl", "classfastly_1_1backend_1_1_backend_builder.html#ac08a92faa8db1b77f7a1231f5e5b74a0", null ],
    [ "enable_pooling", "classfastly_1_1backend_1_1_backend_builder.html#affe8832f47856c4a27710aab453e0674", null ],
    [ "enable_ssl", "classfastly_1_1backend_1_1_backend_builder.html#ac167c4683da60905df0cf42232695565", null ],
    [ "finish", "classfastly_1_1backend_1_1_backend_builder.html#ab88fdc3dfaa8e287783d343170f4288e", null ],
    [ "first_byte_timeout", "classfastly_1_1backend_1_1_backend_builder.html#a29ea17ec6e5332f494331caab6762509", null ],
    [ "http_keepalive_time", "classfastly_1_1backend_1_1_backend_builder.html#a915206e1bb4bfd91b54ce5205532e335", null ],
    [ "override_host", "classfastly_1_1backend_1_1_backend_builder.html#aa0dc4912345b826cf81b108fe209c9d8", null ],
    [ "sni_hostname", "classfastly_1_1backend_1_1_backend_builder.html#afcfc29c60e92ca6ae74cbf786e943642", null ],
    [ "tcp_keepalive_enable", "classfastly_1_1backend_1_1_backend_builder.html#a5566970a7846d1081f9663f9459f739e", null ],
    [ "tcp_keepalive_interval_secs", "classfastly_1_1backend_1_1_backend_builder.html#ad45ee82b683851796d3104e591ff6018", null ],
    [ "tcp_keepalive_probes", "classfastly_1_1backend_1_1_backend_builder.html#a67b7025b3d7b1b159fd2d92f18886a54", null ],
    [ "tcp_keepalive_time_secs", "classfastly_1_1backend_1_1_backend_builder.html#a3d5059d641e9aaea89e6604c653db8b7", null ],
    [ "tls_ciphers", "classfastly_1_1backend_1_1_backend_builder.html#a4ac0fd0be45e910898dc69e7921db651", null ]
];