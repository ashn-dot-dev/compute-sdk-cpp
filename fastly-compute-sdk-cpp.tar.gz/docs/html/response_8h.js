var response_8h =
[
    [ "fastly::http::Response", "classfastly_1_1http_1_1_response.html", "classfastly_1_1http_1_1_response" ],
    [ "fastly::Response", "classfastly_1_1_response.html", "classfastly_1_1_response" ],
    [ "fastly::http::request::select", "namespacefastly_1_1http_1_1request.html#a51ca1c5739c98242822e5303dd0907c0", null ]
];