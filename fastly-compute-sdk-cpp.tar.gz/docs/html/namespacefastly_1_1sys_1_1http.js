var namespacefastly_1_1sys_1_1http =
[
    [ "purge", "namespacefastly_1_1sys_1_1http_1_1purge.html", [
      [ "f_http_purge_purge_surrogate_key", "namespacefastly_1_1sys_1_1http_1_1purge.html#a923b7e513b405e3e9f8e3c5bec7a69b6", null ],
      [ "f_http_purge_soft_purge_surrogate_key", "namespacefastly_1_1sys_1_1http_1_1purge.html#adcdcc9589c92aa4aaad7bf9af3121b2b", null ]
    ] ],
    [ "request", "namespacefastly_1_1sys_1_1http_1_1request.html", [
      [ "f_http_push_box_pending_request_into_vec", "namespacefastly_1_1sys_1_1http_1_1request.html#ab8a79147dcd33443cd3343d492f9ca94", null ],
      [ "f_http_request_select", "namespacefastly_1_1sys_1_1http_1_1request.html#aef11ba213d47a2f8d6c834844d7ec65b", null ],
      [ "m_http_request_pending_request_poll", "namespacefastly_1_1sys_1_1http_1_1request.html#ae4f4b5415d2b481c3cb59ed308ee4ba7", null ],
      [ "m_http_request_pending_request_wait", "namespacefastly_1_1sys_1_1http_1_1request.html#aed7eef154d7d74695baff10d90da6b7b", null ],
      [ "m_http_request_poll_result_into_pending", "namespacefastly_1_1sys_1_1http_1_1request.html#a4884100f118a1de123c3b4b9677aedbf", null ],
      [ "m_http_request_poll_result_into_response", "namespacefastly_1_1sys_1_1http_1_1request.html#ad31fefe3cbdf98e1a3707051fd2d7cbc", null ]
    ] ],
    [ "Method", "namespacefastly_1_1sys_1_1http.html#aefde43db022226c635200348ddf3d8b3", [
      [ "GET", "namespacefastly_1_1sys_1_1http.html#aefde43db022226c635200348ddf3d8b3a7528035a93ee69cedb1dbddb2f0bfcc8", null ],
      [ "POST", "namespacefastly_1_1sys_1_1http.html#aefde43db022226c635200348ddf3d8b3aa02439ec229d8be0e74b0c1602392310", null ],
      [ "PUT", "namespacefastly_1_1sys_1_1http.html#aefde43db022226c635200348ddf3d8b3a3e75383a5992a6d15fb81e872e46e256", null ],
      [ "DELETE", "namespacefastly_1_1sys_1_1http.html#aefde43db022226c635200348ddf3d8b3a32f68a60cef40faedbc6af20298c1a1e", null ],
      [ "HEAD", "namespacefastly_1_1sys_1_1http.html#aefde43db022226c635200348ddf3d8b3ae15e216fc1c639f787b1231ecdfa1bf8", null ],
      [ "OPTIONS", "namespacefastly_1_1sys_1_1http.html#aefde43db022226c635200348ddf3d8b3a164dd62adb30ca051b5289672a572f9b", null ],
      [ "CONNECT", "namespacefastly_1_1sys_1_1http.html#aefde43db022226c635200348ddf3d8b3ab57e2519e26151feacdbe52076bc39ec", null ],
      [ "PATCH", "namespacefastly_1_1sys_1_1http.html#aefde43db022226c635200348ddf3d8b3a63bc9a3997d66d835d9f3ec29451407d", null ],
      [ "TRACE", "namespacefastly_1_1sys_1_1http.html#aefde43db022226c635200348ddf3d8b3a2d3e4144aa384b18849ab9a8abad74d6", null ]
    ] ],
    [ "f_http_status_code_canonical_reason", "namespacefastly_1_1sys_1_1http.html#a0e20b3606678d1d878ea9c6fda5be9b0", null ],
    [ "m_http_request_into_body", "namespacefastly_1_1sys_1_1http.html#ad74a7750dfa77a3b29779817b0e3d47f", null ],
    [ "m_http_request_send", "namespacefastly_1_1sys_1_1http.html#af097ac72df83599b737d18fd4c339370", null ],
    [ "m_http_request_send_async", "namespacefastly_1_1sys_1_1http.html#a1fd96ed065f09eabd41b9c73b4815820", null ],
    [ "m_http_request_send_async_streaming", "namespacefastly_1_1sys_1_1http.html#ab490006c2b5d6fe4300183d7e8135a2b", null ],
    [ "m_http_response_into_body", "namespacefastly_1_1sys_1_1http.html#affda24fd6e529e7c8addea62b27e2a72", null ],
    [ "m_http_response_send_to_client", "namespacefastly_1_1sys_1_1http.html#abc66f5b754cbba884801105efb603807", null ],
    [ "m_http_response_stream_to_client", "namespacefastly_1_1sys_1_1http.html#ac1d914b98ecbd52474f34c8f243af0e1", null ],
    [ "m_http_streaming_body_finish", "namespacefastly_1_1sys_1_1http.html#a45bd321d53a0565e97ee2717b8027993", null ],
    [ "m_static_http_body_new", "namespacefastly_1_1sys_1_1http.html#ad6c19d9d3f22947bb19f2bac0207fba1", null ],
    [ "m_static_http_request_connect", "namespacefastly_1_1sys_1_1http.html#a3466216ffdd29415d29205aed4d42b41", null ],
    [ "m_static_http_request_delete", "namespacefastly_1_1sys_1_1http.html#a35ca4de6d3456d3141c8a685e4321158", null ],
    [ "m_static_http_request_from_client", "namespacefastly_1_1sys_1_1http.html#af2ce456e575683c68929866ad403ec49", null ],
    [ "m_static_http_request_get", "namespacefastly_1_1sys_1_1http.html#a907db90354cc69d3837630ab22ff85f1", null ],
    [ "m_static_http_request_head", "namespacefastly_1_1sys_1_1http.html#a66d67cfd3f53d7d93f49674cb4b0ea8a", null ],
    [ "m_static_http_request_new", "namespacefastly_1_1sys_1_1http.html#a43c1c5bd4196c8afec7aafa8642eb138", null ],
    [ "m_static_http_request_options", "namespacefastly_1_1sys_1_1http.html#a92aca932ca7bab2181510a2ba63d491a", null ],
    [ "m_static_http_request_patch", "namespacefastly_1_1sys_1_1http.html#a4dc784ba2e7eeb1f4642a673d24e4dff", null ],
    [ "m_static_http_request_post", "namespacefastly_1_1sys_1_1http.html#a474a968f241fa6f9e02b07d551363183", null ],
    [ "m_static_http_request_put", "namespacefastly_1_1sys_1_1http.html#a69d1af071aaa321687f063c012f1d3f8", null ],
    [ "m_static_http_request_trace", "namespacefastly_1_1sys_1_1http.html#acdad574e8472431d5a1b4087cbdb68ab", null ],
    [ "m_static_http_response_from_body", "namespacefastly_1_1sys_1_1http.html#a8a09c134d0453c4347a5147c8323ef6e", null ],
    [ "m_static_http_response_from_status", "namespacefastly_1_1sys_1_1http.html#a22181af342f87655fcb90d295fed3572", null ],
    [ "m_static_http_response_new", "namespacefastly_1_1sys_1_1http.html#ad199aa34f44819278ed657372e866c2f", null ],
    [ "m_static_http_response_redirect", "namespacefastly_1_1sys_1_1http.html#aa6939dee942fb52f24d131aa8ed787d6", null ],
    [ "m_static_http_response_see_other", "namespacefastly_1_1sys_1_1http.html#ab9d9997cd4de1146cbad3cdca609fb4b", null ],
    [ "m_static_http_response_temporary_redirect", "namespacefastly_1_1sys_1_1http.html#a8b2ecd50927b3b22dcf5b6cc901816f1", null ]
];