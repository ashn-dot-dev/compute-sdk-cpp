var namespacefastly =
[
    [ "backend", "namespacefastly_1_1backend.html", "namespacefastly_1_1backend" ],
    [ "config_store", "namespacefastly_1_1config__store.html", "namespacefastly_1_1config__store" ],
    [ "device_detection", "namespacefastly_1_1device__detection.html", "namespacefastly_1_1device__detection" ],
    [ "error", "namespacefastly_1_1error.html", "namespacefastly_1_1error" ],
    [ "geo", "namespacefastly_1_1geo.html", "namespacefastly_1_1geo" ],
    [ "http", "namespacefastly_1_1http.html", "namespacefastly_1_1http" ],
    [ "secret_store", "namespacefastly_1_1secret__store.html", "namespacefastly_1_1secret__store" ],
    [ "Body", "classfastly_1_1_body.html", "classfastly_1_1_body" ],
    [ "ConfigStore", "classfastly_1_1_config_store.html", "classfastly_1_1_config_store" ],
    [ "FastlyError", "classfastly_1_1_fastly_error.html", "classfastly_1_1_fastly_error" ],
    [ "Request", "classfastly_1_1_request.html", "classfastly_1_1_request" ],
    [ "Response", "classfastly_1_1_response.html", "classfastly_1_1_response" ],
    [ "SecretStore", "classfastly_1_1_secret_store.html", "classfastly_1_1_secret_store" ],
    [ "expected", "namespacefastly.html#aa62ff3bf88a50b54b7246263c4f55bef", null ],
    [ "unexpected", "namespacefastly.html#a3aa8716ecbb7e10829aad57f1d1959f4", null ],
    [ "FastlyErrorCode", "namespacefastly.html#a62c6d982719867b38eba2a7afd3be598", null ]
];