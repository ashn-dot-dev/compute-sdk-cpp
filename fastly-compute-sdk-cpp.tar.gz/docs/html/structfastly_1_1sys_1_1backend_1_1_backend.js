var structfastly_1_1sys_1_1backend_1_1_backend =
[
    [ "~Backend", "structfastly_1_1sys_1_1backend_1_1_backend.html#a3736d72b3412c95c048c4c095d7de6c1", null ],
    [ "clone", "structfastly_1_1sys_1_1backend_1_1_backend.html#aedf03ad76bf3f9343312f87e210e330f", null ],
    [ "equals", "structfastly_1_1sys_1_1backend_1_1_backend.html#aba01775cc82360c68e508fd8312f686e", null ],
    [ "exists", "structfastly_1_1sys_1_1backend_1_1_backend.html#ae28368d9a746412a2afb1beaeef87ecd", null ],
    [ "get_between_bytes_timeout", "structfastly_1_1sys_1_1backend_1_1_backend.html#a951e342d80f9d5a54e8656fe566ec599", null ],
    [ "get_connect_timeout", "structfastly_1_1sys_1_1backend_1_1_backend.html#a74e32f700f8669dfef6bf14a0c772546", null ],
    [ "get_first_byte_timeout", "structfastly_1_1sys_1_1backend_1_1_backend.html#ac8c408bb848e624d60352ea0afbff928", null ],
    [ "get_host", "structfastly_1_1sys_1_1backend_1_1_backend.html#acc3520e2e90774b0e37b6421a343b47d", null ],
    [ "get_http_keepalive_time", "structfastly_1_1sys_1_1backend_1_1_backend.html#ac027c05a2108c042f2671cea0b173ed4", null ],
    [ "get_port", "structfastly_1_1sys_1_1backend_1_1_backend.html#a6a8b4b80663d99e091657e667b820cb2", null ],
    [ "get_tcp_keepalive_enable", "structfastly_1_1sys_1_1backend_1_1_backend.html#a82e049eab6bc2420d7abde07a3420979", null ],
    [ "get_tcp_keepalive_interval", "structfastly_1_1sys_1_1backend_1_1_backend.html#a8271c4964474ede389b80dfb5ac60dff", null ],
    [ "get_tcp_keepalive_probes", "structfastly_1_1sys_1_1backend_1_1_backend.html#a44aa71af0faad55898371134f1534b12", null ],
    [ "get_tcp_keepalive_time", "structfastly_1_1sys_1_1backend_1_1_backend.html#a62f74e1fabf626ae92617ddf72bf1b5e", null ],
    [ "is_dynamic", "structfastly_1_1sys_1_1backend_1_1_backend.html#a98de833484ff56c8682883c34d08d23e", null ],
    [ "is_ssl", "structfastly_1_1sys_1_1backend_1_1_backend.html#ae888a042610791a9802300e6b6c6a8b7", null ],
    [ "name", "structfastly_1_1sys_1_1backend_1_1_backend.html#a4f058ce911a6b368bf7c0fed9499f886", null ]
];