var namespaces_dup =
[
    [ "fastly", "namespacefastly.html", "namespacefastly" ]
];