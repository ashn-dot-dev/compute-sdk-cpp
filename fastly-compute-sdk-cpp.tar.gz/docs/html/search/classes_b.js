var searchData=
[
  ['request_0',['Request',['../classfastly_1_1http_1_1_request.html',1,'fastly::http::Request'],['../classfastly_1_1_request.html',1,'fastly::Request']]],
  ['response_1',['Response',['../classfastly_1_1http_1_1_response.html',1,'fastly::http::Response'],['../classfastly_1_1_response.html',1,'fastly::Response']]]
];
