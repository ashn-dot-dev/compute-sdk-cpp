var searchData=
[
  ['unauthorized_0',['UNAUTHORIZED',['../classfastly_1_1http_1_1_status_code.html#a1bf0e9ce2f8f2a0200754cc76aaf03f2',1,'fastly::http::StatusCode']]],
  ['unavailable_5ffor_5flegal_5freasons_1',['UNAVAILABLE_FOR_LEGAL_REASONS',['../classfastly_1_1http_1_1_status_code.html#aeca1c2f7d5f2f0109ca965ffc1319764',1,'fastly::http::StatusCode']]],
  ['unprocessable_5fentity_2',['UNPROCESSABLE_ENTITY',['../classfastly_1_1http_1_1_status_code.html#a428902d2d26538dd3d527dc0f212b4c3',1,'fastly::http::StatusCode']]],
  ['unsupported_5fmedia_5ftype_3',['UNSUPPORTED_MEDIA_TYPE',['../classfastly_1_1http_1_1_status_code.html#a625f3f387a5d76c874e772d872add542',1,'fastly::http::StatusCode']]],
  ['upgrade_5frequired_4',['UPGRADE_REQUIRED',['../classfastly_1_1http_1_1_status_code.html#a3966b8866f10a6997b3b3a744da4c383',1,'fastly::http::StatusCode']]],
  ['uri_5ftoo_5flong_5',['URI_TOO_LONG',['../classfastly_1_1http_1_1_status_code.html#acf02c1e24f2c00e3f1c8caa7e0185bc6',1,'fastly::http::StatusCode']]],
  ['use_5fproxy_6',['USE_PROXY',['../classfastly_1_1http_1_1_status_code.html#ae37ce26eeb051f1b12b6f00fd1dc94ca',1,'fastly::http::StatusCode']]]
];
