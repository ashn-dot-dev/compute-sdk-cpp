var searchData=
[
  ['device_5fdetection_2eh_0',['device_detection.h',['../device__detection_8h.html',1,'']]]
];
