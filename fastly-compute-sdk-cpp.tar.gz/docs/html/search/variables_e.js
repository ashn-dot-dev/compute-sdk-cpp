var searchData=
[
  ['see_5fother_0',['SEE_OTHER',['../classfastly_1_1http_1_1_status_code.html#abc8859baec85539e5c4c95d826081ad1',1,'fastly::http::StatusCode']]],
  ['service_5funavailable_1',['SERVICE_UNAVAILABLE',['../classfastly_1_1http_1_1_status_code.html#a09751a1868bb063b08cade5425122c39',1,'fastly::http::StatusCode']]],
  ['switching_5fprotocols_2',['SWITCHING_PROTOCOLS',['../classfastly_1_1http_1_1_status_code.html#ab84ee3d4817a32959484a9825fa5591b',1,'fastly::http::StatusCode']]]
];
