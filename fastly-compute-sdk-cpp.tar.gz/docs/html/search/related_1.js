var searchData=
[
  ['lookup_0',['lookup',['../classfastly_1_1device__detection_1_1_device.html#a17882354a698c180ed8dc3e5917868cb',1,'fastly::device_detection::Device']]]
];
