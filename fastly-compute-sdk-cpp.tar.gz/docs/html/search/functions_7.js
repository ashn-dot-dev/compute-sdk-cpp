var searchData=
[
  ['has_5fbody_0',['has_body',['../classfastly_1_1http_1_1_request.html#a38bd8b681b15d72a2b46a3f6abeaf194',1,'fastly::http::Request::has_body()'],['../classfastly_1_1http_1_1_response.html#ae2dc7cf7ec95c69c525e9be48b5a4950',1,'fastly::http::Response::has_body()'],['../classfastly_1_1_request.html#a38bd8b681b15d72a2b46a3f6abeaf194',1,'fastly::Request::has_body()'],['../classfastly_1_1_response.html#ae2dc7cf7ec95c69c525e9be48b5a4950',1,'fastly::Response::has_body()']]],
  ['head_1',['head',['../classfastly_1_1http_1_1_request.html#a67768acd7c910668639eb3cab1ce29cc',1,'fastly::http::Request::head()'],['../classfastly_1_1_request.html#a67768acd7c910668639eb3cab1ce29cc',1,'fastly::Request::head()']]],
  ['headervaluesiter_2',['HeaderValuesIter',['../classfastly_1_1http_1_1_header_values_iter.html#aab089675950da31d9c47e4b6738a2390',1,'fastly::http::HeaderValuesIter']]],
  ['http_5fkeepalive_5ftime_3',['http_keepalive_time',['../classfastly_1_1backend_1_1_backend_builder.html#a915206e1bb4bfd91b54ce5205532e335',1,'fastly::backend::BackendBuilder']]],
  ['hwtype_4',['hwtype',['../classfastly_1_1device__detection_1_1_device.html#a3c6054bed6385cc51a4a5810116eda82',1,'fastly::device_detection::Device']]]
];
