var searchData=
[
  ['backend_0',['Backend',['../classfastly_1_1backend_1_1_backend.html',1,'fastly::backend']]],
  ['backendbuilder_1',['BackendBuilder',['../classfastly_1_1backend_1_1_backend_builder.html',1,'fastly::backend']]],
  ['body_2',['Body',['../classfastly_1_1_body.html',1,'fastly::Body'],['../classfastly_1_1http_1_1_body.html',1,'fastly::http::Body']]]
];
