var searchData=
[
  ['geo_5flookup_0',['geo_lookup',['../classfastly_1_1geo_1_1_geo.html#a308def92372cab29b28119f0f1cd2480',1,'fastly::geo::Geo']]]
];
