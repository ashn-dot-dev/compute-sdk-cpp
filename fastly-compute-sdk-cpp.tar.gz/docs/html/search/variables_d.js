var searchData=
[
  ['range_5fnot_5fsatisfiable_0',['RANGE_NOT_SATISFIABLE',['../classfastly_1_1http_1_1_status_code.html#a57f8b09c212dc5745cf5c7387f638263',1,'fastly::http::StatusCode']]],
  ['request_5fheader_5ffields_5ftoo_5flarge_1',['REQUEST_HEADER_FIELDS_TOO_LARGE',['../classfastly_1_1http_1_1_status_code.html#a0a0e3ee65ed5a187cabf6afab257be4e',1,'fastly::http::StatusCode']]],
  ['request_5ftimeout_2',['REQUEST_TIMEOUT',['../classfastly_1_1http_1_1_status_code.html#a9ea5591afba3ea4a92da876e84b17907',1,'fastly::http::StatusCode']]],
  ['reset_5fcontent_3',['RESET_CONTENT',['../classfastly_1_1http_1_1_status_code.html#a9278cf95277ba13730443f0388eb3fc1',1,'fastly::http::StatusCode']]]
];
