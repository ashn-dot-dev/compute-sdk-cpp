var searchData=
[
  ['network_5fauthentication_5frequired_0',['NETWORK_AUTHENTICATION_REQUIRED',['../classfastly_1_1http_1_1_status_code.html#a44f627566d6edfe162384c06fb6aeaee',1,'fastly::http::StatusCode']]],
  ['no_5fcontent_1',['NO_CONTENT',['../classfastly_1_1http_1_1_status_code.html#af316db8f88ff3a16c927b224b7805d05',1,'fastly::http::StatusCode']]],
  ['non_5fauthoritative_5finformation_2',['NON_AUTHORITATIVE_INFORMATION',['../classfastly_1_1http_1_1_status_code.html#a13a28a8c11b8feee6fdcc11030ea7e92',1,'fastly::http::StatusCode']]],
  ['not_5facceptable_3',['NOT_ACCEPTABLE',['../classfastly_1_1http_1_1_status_code.html#adf3e7684c40e05f4b6642c43cf1c1ad1',1,'fastly::http::StatusCode']]],
  ['not_5fextended_4',['NOT_EXTENDED',['../classfastly_1_1http_1_1_status_code.html#abb0109cc86a10d5e3ca6fcd49174f3e2',1,'fastly::http::StatusCode']]],
  ['not_5ffound_5',['NOT_FOUND',['../classfastly_1_1http_1_1_status_code.html#a736fbd919131a5febd9a14f100778d87',1,'fastly::http::StatusCode']]],
  ['not_5fimplemented_6',['NOT_IMPLEMENTED',['../classfastly_1_1http_1_1_status_code.html#a444caebbeadccdbb78b33104f6027392',1,'fastly::http::StatusCode']]],
  ['not_5fmodified_7',['NOT_MODIFIED',['../classfastly_1_1http_1_1_status_code.html#a222dfa8af4b840492c79c00b020a1ff0',1,'fastly::http::StatusCode']]]
];
