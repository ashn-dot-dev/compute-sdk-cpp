var searchData=
[
  ['sending_20backend_20requests_0',['Sending backend requests',['../classfastly_1_1_request.html#autotoc_md7',1,'']]],
  ['sending_20to_20the_20client_1',['Sending to the client',['../classfastly_1_1_response.html#autotoc_md25',1,'']]],
  ['setter_20methods_2',['Setter methods',['../classfastly_1_1_request.html#autotoc_md9',1,'Setter methods'],['../classfastly_1_1_response.html#autotoc_md28',1,'Setter methods']]],
  ['style_20methods_3',['style methods',['../classfastly_1_1_request.html#autotoc_md8',1,'Builder-style methods'],['../classfastly_1_1_response.html#autotoc_md27',1,'Builder-style methods']]]
];
