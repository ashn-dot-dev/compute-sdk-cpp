var searchData=
[
  ['client_0',['Sending to the client',['../classfastly_1_1_response.html#autotoc_md25',1,'']]],
  ['client_20request_1',['Getting the client request',['../classfastly_1_1_request.html#autotoc_md5',1,'']]],
  ['conversion_2',['conversion',['../classfastly_1_1_request.html#autotoc_md6',1,'Creation and conversion'],['../classfastly_1_1_response.html#autotoc_md26',1,'Creation and conversion']]],
  ['creation_20and_20conversion_3',['Creation and conversion',['../classfastly_1_1_request.html#autotoc_md6',1,'Creation and conversion'],['../classfastly_1_1_response.html#autotoc_md26',1,'Creation and conversion']]]
];
