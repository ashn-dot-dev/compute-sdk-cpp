var searchData=
[
  ['latitude_0',['latitude',['../classfastly_1_1geo_1_1_geo.html#a4067bbfa01f3d4533c58fd5bfcfb8bfa',1,'fastly::geo::Geo']]],
  ['length_5frequired_1',['LENGTH_REQUIRED',['../classfastly_1_1http_1_1_status_code.html#a8aba84c79a6ad4b6cd3a92a105f55204',1,'fastly::http::StatusCode']]],
  ['locked_2',['LOCKED',['../classfastly_1_1http_1_1_status_code.html#a2297a3aae7753fd7d83c31f32ac8b63b',1,'fastly::http::StatusCode']]],
  ['longitude_3',['longitude',['../classfastly_1_1geo_1_1_geo.html#ab8ae39e8f2e59ef10eddfb457e4cf08e',1,'fastly::geo::Geo']]],
  ['lookup_4',['lookup',['../classfastly_1_1device__detection_1_1_device.html#a17882354a698c180ed8dc3e5917868cb',1,'fastly::device_detection::Device::lookup()'],['../namespacefastly_1_1device__detection.html#a963348758b3806eb80f24a329fc64479',1,'fastly::device_detection::lookup()']]],
  ['loop_5fdetected_5',['LOOP_DETECTED',['../classfastly_1_1http_1_1_status_code.html#a5fe48dd888e1657c05b25316216e15f6',1,'fastly::http::StatusCode']]]
];
