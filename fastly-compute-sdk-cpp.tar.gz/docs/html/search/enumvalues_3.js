var searchData=
[
  ['head_0',['HEAD',['../namespacefastly_1_1sys_1_1http.html#aefde43db022226c635200348ddf3d8b3ae15e216fc1c639f787b1231ecdfa1bf8',1,'fastly::sys::http']]]
];
