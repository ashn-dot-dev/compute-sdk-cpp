var searchData=
[
  ['patch_0',['patch',['../classfastly_1_1http_1_1_request.html#a026667ef07da1430c3eabf35b3c6f708',1,'fastly::http::Request::patch()'],['../classfastly_1_1_request.html#a026667ef07da1430c3eabf35b3c6f708',1,'fastly::Request::patch()']]],
  ['plaintext_1',['plaintext',['../classfastly_1_1secret__store_1_1_secret.html#ac6d874b5440aa447a73acd5315e62e7a',1,'fastly::secret_store::Secret']]],
  ['post_2',['post',['../classfastly_1_1http_1_1_request.html#a222e1fb71935400f5c2da49dc2baf985',1,'fastly::http::Request::post()'],['../classfastly_1_1_request.html#a222e1fb71935400f5c2da49dc2baf985',1,'fastly::Request::post()']]],
  ['postal_5fcode_3',['postal_code',['../classfastly_1_1geo_1_1_geo.html#ae8ca6c56812960139abeef973f4a0f9f',1,'fastly::geo::Geo']]],
  ['proxy_5fdescription_4',['proxy_description',['../classfastly_1_1geo_1_1_geo.html#af0d9a0e0f5bf28cb5b534aa31b951501',1,'fastly::geo::Geo']]],
  ['proxy_5ftype_5',['proxy_type',['../classfastly_1_1geo_1_1_geo.html#abe53920cdfa15bcca98ec75ac3afbd80',1,'fastly::geo::Geo']]],
  ['purge_5fsurrogate_5fkey_6',['purge_surrogate_key',['../namespacefastly_1_1http_1_1purge.html#a778040cf14e4e1a1aaaf07c07552667a',1,'fastly::http::purge']]],
  ['put_7',['put',['../classfastly_1_1http_1_1_request.html#a1dc25bb2e1b484a2087cdccfb3ccc246',1,'fastly::http::Request::put()'],['../classfastly_1_1_request.html#a1dc25bb2e1b484a2087cdccfb3ccc246',1,'fastly::Request::put()']]]
];
