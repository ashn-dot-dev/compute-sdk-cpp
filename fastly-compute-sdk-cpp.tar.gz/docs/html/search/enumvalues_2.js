var searchData=
[
  ['get_0',['GET',['../namespacefastly_1_1sys_1_1http.html#aefde43db022226c635200348ddf3d8b3a7528035a93ee69cedb1dbddb2f0bfcc8',1,'fastly::sys::http']]]
];
