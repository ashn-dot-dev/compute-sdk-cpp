var searchData=
[
  ['http_5fversion_5fnot_5fsupported_0',['HTTP_VERSION_NOT_SUPPORTED',['../classfastly_1_1http_1_1_status_code.html#acd70ee5cadb756cbe181252b6d92e470',1,'fastly::http::StatusCode']]]
];
