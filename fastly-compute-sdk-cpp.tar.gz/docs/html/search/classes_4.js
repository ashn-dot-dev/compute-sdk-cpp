var searchData=
[
  ['geo_0',['Geo',['../classfastly_1_1geo_1_1_geo.html',1,'fastly::geo']]]
];
