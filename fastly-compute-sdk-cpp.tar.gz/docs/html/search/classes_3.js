var searchData=
[
  ['fastlyerror_0',['FastlyError',['../classfastly_1_1error_1_1_fastly_error.html',1,'fastly::error::FastlyError'],['../classfastly_1_1_fastly_error.html',1,'fastly::FastlyError']]]
];
