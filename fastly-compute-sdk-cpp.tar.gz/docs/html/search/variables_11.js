var searchData=
[
  ['variant_5falso_5fnegotiates_0',['VARIANT_ALSO_NEGOTIATES',['../classfastly_1_1http_1_1_status_code.html#a33d2c50a0e162a83996cc34858c1be4b',1,'fastly::http::StatusCode']]]
];
