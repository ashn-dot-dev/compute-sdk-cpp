var searchData=
[
  ['the_20client_0',['Sending to the client',['../classfastly_1_1_response.html#autotoc_md25',1,'']]],
  ['the_20client_20request_1',['Getting the client request',['../classfastly_1_1_request.html#autotoc_md5',1,'']]],
  ['to_20the_20client_2',['Sending to the client',['../classfastly_1_1_response.html#autotoc_md25',1,'']]]
];
