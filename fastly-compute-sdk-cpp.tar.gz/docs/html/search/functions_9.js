var searchData=
[
  ['latitude_0',['latitude',['../classfastly_1_1geo_1_1_geo.html#a4067bbfa01f3d4533c58fd5bfcfb8bfa',1,'fastly::geo::Geo']]],
  ['longitude_1',['longitude',['../classfastly_1_1geo_1_1_geo.html#ab8ae39e8f2e59ef10eddfb457e4cf08e',1,'fastly::geo::Geo']]],
  ['lookup_2',['lookup',['../namespacefastly_1_1device__detection.html#a963348758b3806eb80f24a329fc64479',1,'fastly::device_detection']]]
];
