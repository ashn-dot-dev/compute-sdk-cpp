var searchData=
[
  ['unexpected_0',['unexpected',['../namespacefastly_1_1error.html#a3aa8716ecbb7e10829aad57f1d1959f4',1,'fastly::error::unexpected'],['../namespacefastly.html#a3aa8716ecbb7e10829aad57f1d1959f4',1,'fastly::unexpected']]]
];
