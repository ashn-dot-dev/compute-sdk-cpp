var searchData=
[
  ['metro_5fcode_0',['metro_code',['../classfastly_1_1geo_1_1_geo.html#ab4c3356070f88a6ebc58b05cfd620684',1,'fastly::geo::Geo']]],
  ['minutes_5fpast_5fhour_1',['minutes_past_hour',['../classfastly_1_1geo_1_1_utc_offset.html#aacf1444ab56f4b66f9dac47e8c10460d',1,'fastly::geo::UtcOffset']]],
  ['model_2',['model',['../classfastly_1_1device__detection_1_1_device.html#a35dbfe715296cc1f9e3f589b1e61e3a4',1,'fastly::device_detection::Device']]]
];
