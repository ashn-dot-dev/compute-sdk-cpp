var searchData=
[
  ['delete_5f_0',['delete_',['../classfastly_1_1http_1_1_request.html#a4346806bf6cdf24f1eb4de42faafcf38',1,'fastly::http::Request::delete_()'],['../classfastly_1_1_request.html#a4346806bf6cdf24f1eb4de42faafcf38',1,'fastly::Request::delete_()']]],
  ['device_5fname_1',['device_name',['../classfastly_1_1device__detection_1_1_device.html#adb8837d1b415101ba0fe213597418808',1,'fastly::device_detection::Device']]],
  ['disable_5fssl_2',['disable_ssl',['../classfastly_1_1backend_1_1_backend_builder.html#ac08a92faa8db1b77f7a1231f5e5b74a0',1,'fastly::backend::BackendBuilder']]]
];
