var searchData=
[
  ['underflow_0',['underflow',['../classfastly_1_1http_1_1_body.html#a19cde7f8937f12eddc382e86dc2fd487',1,'fastly::http::Body::underflow()'],['../classfastly_1_1_body.html#a19cde7f8937f12eddc382e86dc2fd487',1,'fastly::Body::underflow()']]],
  ['utc_5foffset_1',['utc_offset',['../classfastly_1_1geo_1_1_geo.html#a50a5f8a41434cebbf6a356acf4788740',1,'fastly::geo::Geo']]]
];
