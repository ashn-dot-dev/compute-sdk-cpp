var searchData=
[
  ['unexpected_0',['unexpected',['../namespacefastly_1_1error.html#a3aa8716ecbb7e10829aad57f1d1959f4',1,'fastly::error::unexpected'],['../namespacefastly.html#a3aa8716ecbb7e10829aad57f1d1959f4',1,'fastly::unexpected']]],
  ['unexpected_5ftype_1',['unexpected_type',['../classtl_1_1expected.html#ad7177eece2a4d803f244ef2a19b14c46',1,'tl::expected']]]
];
