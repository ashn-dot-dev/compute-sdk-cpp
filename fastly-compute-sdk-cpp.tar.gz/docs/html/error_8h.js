var error_8h =
[
    [ "fastly::error::FastlyError", "classfastly_1_1error_1_1_fastly_error.html", "classfastly_1_1error_1_1_fastly_error" ],
    [ "fastly::FastlyError", "classfastly_1_1_fastly_error.html", "classfastly_1_1_fastly_error" ],
    [ "fastly::error::expected", "namespacefastly_1_1error.html#aa62ff3bf88a50b54b7246263c4f55bef", null ],
    [ "fastly::expected", "namespacefastly.html#aa62ff3bf88a50b54b7246263c4f55bef", null ],
    [ "fastly::error::unexpected", "namespacefastly_1_1error.html#a3aa8716ecbb7e10829aad57f1d1959f4", null ],
    [ "fastly::unexpected", "namespacefastly.html#a3aa8716ecbb7e10829aad57f1d1959f4", null ],
    [ "fastly::error::FastlyErrorCode", "namespacefastly_1_1error.html#a62c6d982719867b38eba2a7afd3be598", null ],
    [ "fastly::FastlyErrorCode", "namespacefastly.html#a62c6d982719867b38eba2a7afd3be598", null ]
];