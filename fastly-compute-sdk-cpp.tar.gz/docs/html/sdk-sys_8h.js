var sdk_sys_8h =
[
    [ "CXXBRIDGE1_ENUM_fastly", "sdk-sys_8h.html#ae05010887d18c8f6e32e4c0256e16baa", null ],
    [ "CXXBRIDGE1_IS_COMPLETE", "sdk-sys_8h.html#a0cb2633f1a920564da379f9b9444992c", null ],
    [ "CXXBRIDGE1_LAYOUT", "sdk-sys_8h.html#a88f3c6437fd394530e6345cec73af65d", null ],
    [ "CXXBRIDGE1_PANIC", "sdk-sys_8h.html#a381e1e6930e067e75951a391b5afba35", null ],
    [ "CXXBRIDGE1_RUST_BITCOPY_T", "sdk-sys_8h.html#a4a5fb80a21eff1607688b7cc1027dab3", null ],
    [ "CXXBRIDGE1_RUST_BOX", "sdk-sys_8h.html#a90b37fc7d92f99833b76828e0de4df56", null ],
    [ "CXXBRIDGE1_RUST_OPAQUE", "sdk-sys_8h.html#a2e5ae71e53ed5a7f80c70fa201d93c8e", null ],
    [ "CXXBRIDGE1_RUST_SLICE", "sdk-sys_8h.html#ae3895ba514efcc7f8b54adfee27a636b", null ],
    [ "CXXBRIDGE1_RUST_STR", "sdk-sys_8h.html#a189ef565bbf3ed2bf6306b034121f736", null ],
    [ "CXXBRIDGE1_RUST_STRING", "sdk-sys_8h.html#a257c9d5fc0087692807f890f248e532e", null ],
    [ "CXXBRIDGE1_RUST_VEC", "sdk-sys_8h.html#ab2b9c008a3d5f3a6d4c06561d117a501", null ],
    [ "CXXBRIDGE1_STRUCT_fastly", "sdk-sys_8h.html#ae80689f3fbfcab1c46e9496732fb3d64", null ]
];