var namespacefastly_1_1http_1_1request =
[
    [ "PendingRequest", "classfastly_1_1http_1_1request_1_1_pending_request.html", "classfastly_1_1http_1_1request_1_1_pending_request" ],
    [ "select", "namespacefastly_1_1http_1_1request.html#a51ca1c5739c98242822e5303dd0907c0", null ]
];