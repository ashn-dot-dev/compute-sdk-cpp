var classfastly_1_1geo_1_1_utc_offset =
[
    [ "is_negative", "classfastly_1_1geo_1_1_utc_offset.html#a54dfc7e99df284519ac0810bc3d10bc1", null ],
    [ "is_positive", "classfastly_1_1geo_1_1_utc_offset.html#a3c254fe07ac6f03b936d0c5405f1e9e2", null ],
    [ "is_utc", "classfastly_1_1geo_1_1_utc_offset.html#a754e9a66a72d7a252552f140b4133405", null ],
    [ "minutes_past_hour", "classfastly_1_1geo_1_1_utc_offset.html#aacf1444ab56f4b66f9dac47e8c10460d", null ],
    [ "seconds_past_minute", "classfastly_1_1geo_1_1_utc_offset.html#ab4c205062d0283476f15232fece63580", null ],
    [ "whole_hours", "classfastly_1_1geo_1_1_utc_offset.html#afa7801ab16a2e53093c1ab6ce3073ad9", null ],
    [ "whole_minutes", "classfastly_1_1geo_1_1_utc_offset.html#addea0554882ebe003deeeaafbdb6f817", null ],
    [ "whole_seconds", "classfastly_1_1geo_1_1_utc_offset.html#a4c3b0a6611e3588fd587490f28432e10", null ]
];