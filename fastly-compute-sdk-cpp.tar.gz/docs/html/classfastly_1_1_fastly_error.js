var classfastly_1_1_fastly_error =
[
    [ "FastlyError", "classfastly_1_1_fastly_error.html#a197ace6c4dced6e3df6f4da703ab0f88", null ],
    [ "FastlyError", "classfastly_1_1_fastly_error.html#a75d47a6d02c89451c2c9715d04112e36", null ],
    [ "error_code", "classfastly_1_1_fastly_error.html#abab37bf1c41c7d3603e48ad945426295", null ],
    [ "error_msg", "classfastly_1_1_fastly_error.html#a148757387bfe822197ccc13a423cb584", null ]
];