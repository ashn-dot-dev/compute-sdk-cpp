var namespacefastly_1_1error =
[
    [ "FastlyError", "classfastly_1_1error_1_1_fastly_error.html", "classfastly_1_1error_1_1_fastly_error" ],
    [ "expected", "namespacefastly_1_1error.html#aa62ff3bf88a50b54b7246263c4f55bef", null ],
    [ "unexpected", "namespacefastly_1_1error.html#a3aa8716ecbb7e10829aad57f1d1959f4", null ],
    [ "FastlyErrorCode", "namespacefastly_1_1error.html#a62c6d982719867b38eba2a7afd3be598", null ]
];